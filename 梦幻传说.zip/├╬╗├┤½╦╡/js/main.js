setInterval(function() {
	//实时更新数据
	Update();
	//改变页面大小
	//ChangeSize();
	//测试
	ctx.clearRect(0, 0, Pw, Ph)
	switch(state) {
		case 1:
			Case1();
			break
		case 2:
			Case2();
			break
	}
}, 10);
Case1 = function() {
	if (loading < 100) {
		loading +=4
	}
	//加载中
	ctx.fillStyle = "white"
	ctx.font = sC(60) + "px Comic Sans MS"
	ctx.fillRect(0, 0, Pw, Ph)
	ctx.fillStyle = "lime"
	ctx.fillText("loading:       " + Math.round(loading) + "%", xC(500), yC(300))
	if (loading >= 100) {
		state = 2
		Initializing(game)
	}
	ctx.fillStyle = "rgb(100,10,10)"
	ctx.fillRect(xC(345), yC(445), sC(810), sC(80))
	ctx.fillStyle = "white"
	ctx.fillRect(xC(350), yC(450), sC(800), sC(70))
	ctx.fillStyle = "#00a8f3"
	ctx.fillRect(xC(350), yC(450), sC(8 * loading), sC(70))
	ctx.fillStyle = "#68cffd"
	ctx.fillRect(xC(350), yC(450), sC(8 * loading), sC(30))
}
function Case2() {
	BgPaint();
	Allpaint();
	Allmove();
	Allcheck();
	Hlocated();
	AutoCreatEnemy(game)
	CheckWorldThrough();
}