//自适应屏幕
function ChangeSize() {
	var w = window.innerWidth
	var h = window.innerHeight
	if (w * 0.5 >= h) {
		canvas.width = h / 0.5
		canvas.height = h
	} else {
		canvas.width = w
		canvas.height = w * 0.5
	}
	Pw = canvas.width
	Ph = canvas.height
}

//getPointOnCanvas方法
function getPoint(x, y) {
	var bbox = canvas.getBoundingClientRect();
	return {
		x : x - bbox.left,
		y : y - bbox.top
	};
}

//判断转换坐标
function xC(x) {//x坐标转化
	var xx = x
	if (x <= 750) {
		xx = x * Pw / 1500
	} else {
		xx = Pw - (1500 - x) * Pw / 1500
	}
	return xx
}

function yC(y) {//y坐标转化
	var yy = y
	if (y <= 375) {
		yy = y * Ph / 750
	} else {
		yy = Ph - (750 - y) * Ph / 750
	}
	return yy
}

function sC(v) {//大小转化
	var vv = v
	vv = Pw / 1500 * v
	return vv
}

//英雄
function H(type, x, y, lv, life, magic, lifeback, magicback, dmg, escape, defense, kill, wear, team, accurance, toughness, ifDiePlus, expGain, detailPaint) {//种类,释放x,释放y,等级,生命，魔法值，回血，回蓝，闪避，防御，暴击,穿着,战队,命中，韧性，死后是否算本分割世界通关数量,死后获得经验
	this.team = team//1:我方   2:敌方   3：中立方
	this.type = type
	this.detailPaint = detailPaint//战斗数据是否显示
	if (this.detailPaint == undefined) {
		this.detailPaint = [false, 0, 0]
	}
	this.eHome = []//所有效果（类型）
	/*
	 1:无敌
	 */
	this.eIndex = []//累加index
	this.eTime = []//持续时间
	this.eIfForever = []//是否永久持续
	this.eDetail = []//细节
	this.x = x//中心点
	this.y = y
	this.lv = lv
	this.life = life
	this.magic = magic
	this.lifeback = lifeback
	this.magicback = magicback
	this.dmg = dmg
	this.escape = escape
	this.defense = defense
	this.accurance = accurance
	this.kill = kill
	this.toughness = toughness
	//初始值
	this.bw = this.w
	this.bh = this.h
	this.bdmg = dmg
	this.blife = life
	this.bmagic = magic
	this.blifeback = lifeback
	this.bmagicback = magicback
	this.bescape = escape
	this.bdefense = defense
	this.baccurance = accurance
	this.bkill = kill
	this.btoughness = toughness
	//装扮
	this.wear = wear
	this.backin = 0//回复index
	this.canDelete = 0
	this.runin = 0//奔跑idex
	this.runindex = 0
	this.state = 1//状态：1慢跑，2快跑，3攻击，4被攻击
	this.dmgstate = 0//0普通攻击
	this.g = 0.3//竖直方向重力加速度
	this.aa = 0.2//水平方向动力加速度(自动力)
	this.miu = 0.05//地面摩擦
	this.v = 0
	this.vmax = 1
	this.vx = 0
	this.vy = 0
	this.xmove = false//x方向是否运动
	this.ymove = false//y方向是否运动
	this.ystop = false
	this.expGain = expGain
	if (this.expGain == undefined) {
		this.expGain = 0
	}
	this.ifDiePlus = ifDiePlus
	if (this.ifDiePlus == undefined) {
		this.ifDiePlus = false
	}
	this.hide = false//隐身
	//各个部位旋转角度
	this.bodyUpD = 0//上半身（最最主要的）(//空翻度数)
	this.bodyDownD = 0//下半身
	this.armLD = 0//左1
	this.armRD = 0//右1
	this.armLD2 = 0//左2
	this.armRD2 = 0//右2
	this.headD = 0//头
	this.legLD = 0//左
	this.legRD = 0//右
	this.legRD2 = 0//左
	this.legLD2 = 0//右
	this.trousersD1 = 0//1
	this.trousersD2 = 0//1
	this.trousersD3 = 0//1
	this.weaponD = 0//武器
	//各个部位图片编号
	this.headF = -2//头
	this.headWearF = 0//头饰
	this.clothF = 0//衣饰
	this.trousersF = 0//裤子
	this.weaponF = -1//武器
	//武器xy(以中心点为原点移动)
	this.weaponX = 0
	this.weaponY = 0
	this.armDspeed = Math.PI / 100
	//整体xy(以中心点为原点移动)
	this.bodyX = 0
	this.bodyY = 0
	this.runD = 0
	this.rotateSpeed = 0//旋转速度
	this.weaponhand = 1//武器是否在人物图层之下(右手还是左手使用武器)
	this.ifAirStop = false//是否悬停
	this.ifundmged = false, this.undmgedin = 0//无敌
	this.ifunbeated = false, this.unbeatedin = 0//霸体
	this.size = 1//大小
	if (this.type == -0.1) {//萝卜
		this.name = "胡萝卜"
		this.img = object[1]
		this.w = 40
		this.h = 40
		this.v = 0
		this.ifundmged = true
		this.team = 5
	}
	if (this.type == -0.2) {//魔瓶
		this.name = "魔瓶"
		this.img = object[2]
		this.w = 40
		this.h = 40
		this.v = 0
		this.ifundmged = true
		this.team = 5
	}
	if (this.type == -0.3) {//传送门
		this.name = "传送门"
		this.img = expressDoor
		this.w = 200
		this.h = 200
		this.v = 0
		this.undmged = true
		this.fin = 0
		this.frame = 0
		this.expressDisplay = false
		this.team = 5
	}
	if (this.type == 1) {//主英雄:
		this.name = "行者"
		this.a = 0.2
		this.vmax = 4
		this.m = 10
		this.w = 60
		this.h = 160
		this.attackDuration = [25, 25, 100, 75, 40, 50, 220, 250]//每一步攻击花费的时间60
		this.commonAttackActionNumber = [4, 1, 1, 1, 1]//攻阶段数(普攻,技能1)
		this.protectmax = 30
		this.runFrameIndex = 0
		this.skillCostMagic = [];
		this.eHome = []//所有效果（类型）
		/*
		 1:无敌
		 */
		this.eIndex = []//累加index
		this.eTime = []//持续时间
		this.eIfForever = []//是否永久持续
		this.eDetail = []//细节
		this.eImage= []//标识照片
	}
	if (this.type == 2) {//敌人
		this.name = "蘑菇怪"
		this.a = 0
		this.vmax = 2
		this.v = 2
		this.m = 10
		this.w = 120
		this.h = 120
		this.attackDuration = [60]//每一步攻击花费的时间
		this.attackRest = [[300, 350]]//每技能使用后休息时间
		this.attackNeedLife = [1]//什么时候触发（血量百分比）
		//this.attackProbability = [1]//每招几率
		this.attackDis = [100]//每招所需距离
		this.attackNum = 0//释放这一技能
		this.commonAttackActionNumber = [1]//攻阶段数(普攻,技能1)
		this.headF = 2
		this.dis = 600
		this.restTime = [1000, 1200]//走路休息时长
		this.protectmax = 1e10
	}
	if (this.type == 3) {//敌人
		this.name = "百菌仙"
		this.a = 0
		this.vmax = 2.5
		this.v = 2.5
		this.m = 10
		this.w = 80
		this.h = 200
		this.attackDuration = [80, 150, 80]//每一步攻击花费的时间
		this.attackRest = [[200, 250], [200, 250], [350, 400]]//每技能使用后休息时间
		this.attackNeedLife = [1, 1, 0.5]//什么时候触发（血量百分比）
		//this.attackProbability = [1,0]//每招几率
		this.attackDis = [200, 250, 1500]//每招所需距离
		this.attackNum = 0//释放这一技能
		this.commonAttackActionNumber = [1, 1, 1]//攻阶段数(普攻,技能1)
		this.dis = 1500
		this.restTime = [1400, 1600]//走路休息时长
		this.protectmax = 50
		this.headF = 4
		this.weaponD = Math.PI / 2
		this.hairD1 = 0
		this.hairD2 = 0
		this.hairD3 = 0
	}
	this.ifAttackFinished = true//攻击完一次后的休息
	this.attackFinishedin = 0
	this.lastAttackNum = 0//上一个释放的技能
	this.restin = 0//判断是否需要休息
	this.ifrest = false
	this.restindex = 0;
	//休息时index
	this.G = this.m * this.g//重力
	this.alp = 100//透明度
	this.jtime = 0
	this.t = 1//方向
	this.rfinished = true
	this.ifjump = false//是否跳跃
	this.availableJumpTime = 2//可跳跃次数
	this.runstate = 1//奔跑状态
	this.runsin = 0//改变奔跑状态index
	this.ifrunready = false//是否连按两次奔跑
	this.actn = 1//动作编号
	this.actin = 0//检查是否连击
	this.ifActKeyDown = false//攻击键是否按下
	this.actfinished = true//一次动作是否完成
	this.actindex = 0//进行该动作index
	this.actstate = 0//0:普攻,1：1技能
	this.bla = 100//血条透明度
	this.blin = 0
	this.lastbl = this.life//上一次检查血量数
	this.beatenin = 0
	//wh初始化
	this.bw = this.w
	this.bh = this.h
	this.beatenv = 0
	this.beatenAboveindex = 0//被击打浮空index
	this.dyingindex = 0
	//传送参量
	this.express = false
	this.expressin = 0
	//禁止项目
	this.NoJump = false//禁跳
	this.NoAttack = false//禁止普攻
	this.NoSkill = false//禁技
	this.NoMove = false//禁止移动
	this.walkDis = 300//步行距离
	this.walkTime = Math.random() * this.walkDis//单次步行时间
	this.walkside = -1//停在板块的左还是右（-1：左，1右）
	this.walkStop = false//自动走路时遇到边缘停下
	this.goal = -1//目标
	this.goalLocked = false//目标是否锁定
	this.throughArr = [];
	//已贯穿的项
	this.downindex = 0//跌倒index
	this.fallindex = 0//摔倒旋转index
	this.ifdown = false//是否将要跌倒
	this.ifTouchedGround = false//是否跌倒已触及地面
	this.protectindex = 0//自我保护
	this.lastlife = this.life
	this.lastmagic = this.magic//10毫秒前的血量与魔法
	this.lifeCut = this.life//血条回调
	this.magicCut = this.magic//魔法回调
	this.weaponSize = 1
	this.poison = function(ptime, pdmg) {
		var pt = 0
		var a = setInterval(function() {
			this.life -= pdmg
			pt++
			if (pt >= ptime) {
				return clearInterval(a)
			}
		}, 1000)
	}
	//自动攻击
	this.AutoAttack = function() {
		//动作更替
		if (this.attackNum >= this.attackDuration.length) {
			this.attackNum = 0
		}
		//判断攻击后的短暂休息
		if (this.ifAttackFinished) {
			this.attackFinishedin++
			if (this.attackFinishedin >= Math.random() * (this.attackRest[this.lastAttackNum][1] - this.attackRest[this.lastAttackNum][0]) + this.attackRest[this.lastAttackNum][0]) {
				this.attackFinishedin = 0
				this.ifAttackFinished = false
			}
		} else {
			if (this.life > this.blife * this.attackNeedLife[this.attackNum]) {
				this.attackNum = 0
			}
			this.attackFinishedin = 0
			//检查是否在范围内
			if (hs[this.goal] != undefined) {
				var xx1 = Math.abs(hs[this.goal].x - this.x), yy1 = Math.abs(hs[this.goal].y - this.y), xy1 = Math.sqrt(xx1 * xx1 + yy1 * yy1)
				if (xy1 <= this.dis) {
					//本应释放的技能
					if (xy1 <= this.attackDis[this.attackNum] && this.life <= this.blife * this.attackNeedLife[this.attackNum]) {
						this.actstate = this.attackNum
						this.lastAttackNum = this.attackNum
						this.state = 2
						if (this.actfinished) {
							if (hs[this.goal].x > this.x) {
								this.t = 1
							} else {
								this.t = -1
							}
						}
						this.actfinished = false
					}
				}
			}
		}
	}
	//自动休息
	this.AutoRest = function() {
		if (this.state == 1) {
			if (!this.ifrest) {
				this.restin++
				this.restindex = 0
				if (this.restin >= Math.random() * (this.restTime[1] - this.restTime[0]) + this.restTime[0]) {
					this.ifrest = true
				}
			} else {
				this.v = 0
				this.restin = 0
				this.restindex++
				this.xmove = false
				if (this.restindex >= 200) {
					this.ifrest = false
					this.v = this.vmax
				}
			}
		}
	}
	//自动走路
	this.AutoWalk = function() {
		if (this.state == 1) {
			if (hs[this.goal] == undefined || this.ifAttackFinished) {
				this.xmove = true
				this.runsin++
				if (this.runsin >= this.walkTime) {
					this.walkTime = Math.random() * this.walkDis
					this.walkStop = false
					this.t = -this.t
					this.runsin = 0
				}
				if (this.walkStop && this.walkside == this.t) {
					this.walkTime = Math.random() * this.walkDis
					this.walkStop = false
					this.t = -this.t
					this.runsin = 0
				}
				//到边缘停止
				if (this.walkStop) {
					if (this.t == this.walkside) {
						this.v = 0
					}
				} else {
					this.v = this.vmax
				}
			}
			if (hs[this.goal] != undefined && !this.ifAttackFinished) {
				this.xmove = true
				//追击敌人
				if (hs[this.goal].x + hs[this.goal].w / 2 <= this.x - this.w / 2) {
					this.t = -1
				}
				if (hs[this.goal].x - hs[this.goal].w / 2 >= this.x + this.w / 2) {
					this.t = 1
				}
				this.v = this.vmax
			}
		} else {
			this.xmove = false
		}
	}
	this.checkEnemy = function() {
		var xyhome = []
		if (hs[this.goal] == undefined) {
			this.goal = -1
		}
		//检查是否超出范围
		if (hs[this.goal] != undefined) {
			var xx1 = Math.abs(hs[this.goal].x - this.x), yy1 = Math.abs(hs[this.goal].y - this.y), xy1 = Math.sqrt(xx1 * xx1 + yy1 * yy1)
			if (xy1 > this.dis) {
				this.goal = -1
			}
			if (hs[this.goal].y + hs[this.goal].h / 2 < this.y - this.h / 2 || hs[this.goal].y - hs[this.goal].h / 2 > this.y + this.h / 2) {
				this.goal = -1
			}
			//是否是队友
			if (hs[this.goal].team == this.team || hs[this.goal].type < 0) {
				this.goal = -1
			}
		}
		if (hs[this.goal] == undefined || !this.goalLocked) {
			for (var i = 0; i < hs.length; i++) {
				var xx = Math.abs(hs[i].x - this.x), yy = Math.abs(hs[i].y - this.y), xy = Math.sqrt(xx * xx + yy * yy)
				if (hs[i].team != this.team && hs[i].life > 0 && hs[i].type > 0 && !hs[i].hide) {
					//非队友
					if (xy <= this.dis && hs[i].y + hs[i].h / 2 >= this.y - this.h / 2 && hs[i].y - hs[i].h / 2 <= this.y + this.h / 2) {
						//在范围内
						xyhome[xyhome.length] = xy
					}
				}
			}
			var truexy = Math.min.apply(null, xyhome)
			//遍历寻找
			for (var i = 0; i < hs.length; i++) {
				var xx = Math.abs(hs[i].x - this.x), yy = Math.abs(hs[i].y - this.y), xy = Math.sqrt(xx * xx + yy * yy)
				if (hs[i].team != this.team && hs[i].life > 0 && hs[i].type > 0) {
					//非队友
					if (xy == truexy) {
						this.goal = i;
						break
					}
				}
			}
		}
	}
	this.paint = function(ctx) {
		this.allPaint(ctx);
		this.bloodpaint();
		this.heroDetailPaint();
	}
	this.move = function() {
		this.sizeCheck();
		if (this.type > 0) {
			this.frameCheck();
			//实时更新数据
			this.upDate();
			this.bloodMagicCheck();
			this.checkSelfProtection();//自我保护
			}
		this.AllDChange();
		//角度转化
		//魔瓶,萝卜,传送一栏
		this.Given();
		//补给品
		//传送
		this.expressCheck();
		//非补给品
		if (this.state != 4) {//非死亡
			this.allEffectionWork();
			this.allEffectionDisplay();
			if (this.state != 3) {//非被打
				//运动判断
				this.xmoveCheck();
				if (this.type > 0) {
					this.act();
				}
				//蘑菇怪
				if (this.team == 2) {
					//自动行走
					this.AutoWalk();
					this.AutoRest();
					this.checkEnemy();
					this.AutoAttack();
				}
			} else {
				//被打
				this.beatenBack();
			}
			if (this.type > 0) {
				this.frameCheck();
			}
		} else {
			//死亡
			this.dying()
		}
		//受力分析
		this.Fcheck();
		this.borderCheck();
	}
	this.Fcheck = function() {
		this.gravity();
		//重力模拟
		this.stopFall();
		//掉落平台
	}
	this.gravity = function() {
		if (!this.ystop) {
			if (!this.ifAirStop) {
				this.vy += this.g
			}
			this.y += this.vy
		} else {
			if (!this.ifjump) {
				this.vy = 0
			} else {
				if (!this.ifAirStop) {
					this.vy += this.g
				}
				this.y += this.vy
			}
		}
	}
	this.bloodMagicCheck = function() {
		if (this.type > 0) {
			//检查血量是否减少
			if (this.lastbl == this.life) {
				this.blin++
				if (this.blin >= 200) {
					if (this.bla > 0) {
						this.bla--
					}
				}
			} else {
				this.blin = 0
				this.bla = 100
			}
			this.lastbl = this.life
			//回复
			this.backin++
			if (this.backin >= 500&&this.state!=4) {
				this.life += this.lifeback * 5
				this.magic += this.magicback * 5
				this.backin = 0
			}
			if (this.life >= this.blife) {
				this.life = this.blife
			}
			if (this.magic >= this.bmagic) {
				this.magic = this.bmagic
			}
			if (this.life <= 0) {
				this.life = 0
				if (this.state != 4) {
					if (this.ifDiePlus) {
						beatedENum++
					}
					this.state = 4
					this.bodyUpD = 0
				}
			}
			if (this.magic <= 0) {
				this.magic = 0
			}
		}
	}
	this.backround = function() {
		if (this.type == 1) {
			if (Math.abs(this.bodyUpD) < Math.PI * 2) {
				if (this.jtime >= 2) {
					this.bodyUpD += Math.PI / 20
				}
			} else {
				this.rfinished = true
			}
			//抬头
			if (this.state == 1) {
				if (!this.ystop) {
					if (this.vy >= 0) {
						this.headD = Math.PI / 24
					} else {
						this.headD = -Math.PI / 24
					}
				} else {
					this.headD = 0
				}
			}
		}
	}
	this.xmoveCheck = function() {
		//行者
		if (this.type == 1) {
			//走路
			if (this.state == 1) {
				//中心归位
				//this.bodyUpD = 0
				//踮脚
				//跑步摆臂
				this.weaponSize = 1
				if (!this.xmove) {
					this.bodyX = 0
					this.bodyY = 0
					this.runFrameIndex = 0
					this.runindex = 0
					this.runD = 0
					if (this.v > 0) {
						this.v -= this.aa
					} else {
						this.v = 0
					}
					if (this.ystop) {
						this.armLD = 0
						this.armRD = 0
						this.legRD = 0
						this.legLD = 0
						this.armLD2 = 0
						this.armRD2 = 0
						this.legRD2 = 0
						this.legLD2 = 0
						this.runD = 0
						this.trousersD1 = 0
						this.trousersD2 = 0
						this.trousersD3 = 0
						this.weaponD = Math.PI / 2
						this.armDspeed = Math.PI / 120
						this.weaponhand = 1
					}
				} else {
					this.runindex++
					if (this.runindex >= 30) {
						this.runindex -= 30
					}
					var vvvvv = 30 * this.g / 4
					if (!this.ystop) {
						this.bodyY = 0
					} else {
						this.bodyY = -vvvvv * this.runindex + this.runindex * this.g * this.runindex / 4
					}
					if (this.v < this.vmax) {
						this.v += this.aa
					}
					this.weaponhand = -1
					this.runD += this.armDspeed * 2
					this.armLD = Math.PI / 6
					this.armRD = -this.runD
					this.armLD2 = 0
					this.armRD2 = -this.runD - Math.PI / 6
					if (this.ystop) {
						this.legRD = this.runD
						this.legLD = -this.runD
						this.legRD2 = this.runD * 1.2 + Math.PI / 3
						this.legLD2 = -this.runD * 1.2 + Math.PI / 3
						this.trousersD1 = Math.abs(this.runD)
						this.trousersD2 = 0
						this.trousersD3 = -Math.abs(this.runD)
					} else {
						this.legLD = 0
						this.legRD = -Math.PI / 4
						this.trousersD1 = 0
						this.trousersD2 = 0
						this.trousersD3 = -Math.PI / 4
					}
					this.weaponD = Math.PI / 6
					if (this.armRD >= Math.PI / 4 || this.armRD <= -Math.PI / 4) {
						this.armDspeed = -this.armDspeed
					}
				}
			}
		}
		//百菌仙
		if (type == 3) {
			if (this.state == 1) {
				this.runindex++
				this.bodyX = 0
				this.bodyY = 0
				this.bodyUpD = 0
				this.weaponhand = 1
				if (this.runindex >= 80) {
					this.runindex = 0
				} else {
					if (this.runindex <= 40) {
						this.hairD1 = Math.PI / 200 * this.runindex
						this.hairD2 = Math.PI / 200 * this.runindex
						this.hairD3 = Math.PI / 200 * this.runindex
						this.trousersD1 = Math.PI / 400 * this.runindex
						this.trousersD2 = -Math.PI / 400 * this.runindex
						this.trousersD3 = 0
						this.armLD = Math.PI / 400 * this.runindex
						this.armLD2 = Math.PI / 400 * this.runindex
						this.armRD = -Math.PI / 400 * this.runindex
						this.armRD2 = -Math.PI / 400 * this.runindex
						this.weaponD = Math.PI / 400 * this.runindex + Math.PI / 2
					} else {
						this.hairD1 = -Math.PI / 200 * (this.runindex - 40) + Math.PI / 5
						this.hairD2 = -Math.PI / 200 * (this.runindex - 40) + Math.PI / 5
						this.hairD3 = -Math.PI / 200 * (this.runindex - 40) + Math.PI / 5
						this.trousersD1 = -Math.PI / 400 * (this.runindex - 40) + Math.PI / 10
						this.trousersD2 = Math.PI / 400 * (this.runindex - 40) - Math.PI / 10
						this.trousersD3 = 0
						this.armLD = -Math.PI / 400 * (this.runindex - 40) + Math.PI / 10
						this.armLD2 = -Math.PI / 400 * (this.runindex - 40) + Math.PI / 10
						this.armRD = Math.PI / 400 * (this.runindex - 40) - Math.PI / 10
						this.armRD2 = Math.PI / 400 * (this.runindex - 40) - Math.PI / 10
						this.weaponD = -Math.PI / 400 * (this.runindex - 40) + Math.PI / 10 + Math.PI / 2
					}
				}
			} else {
				this.runindex = 0
			}
		}
		//速度加成
		this.x += this.t * this.v
	}
	this.stopFall = function() {//停止降落
		var ifstop = false
		if (this.vy != 0) {
			this.ystop = false
		}
		this.walkStop = false
		for (var i = 0; i < bgs.length; i++) {
			//平台
			if (bgs[i].canstop == 1) {
				//停下
				if (bgs[i].x + bgs[i].w / 2 >= this.x - this.w / 2 && bgs[i].x - bgs[i].w / 2 <= this.x + this.w / 2) {
					var nb = false
					//自动判断是否到边缘
					//步行距离
					this.walkDis = bgs[i].w
					if (bgs[i].ifNian) {
						if (this.y + this.h / 2 >= bgs[i].y - bgs[i].h / 2 && this.y - this.h / 2 < bgs[i].y + bgs[i].h / 2) {
							nb = true
						}
					} else {
						if (this.y + this.h / 2 >= bgs[i].y - bgs[i].h / 2 && this.y + this.h / 2 <= bgs[i].y - bgs[i].h / 2 + 20) {
							nb = true
						}
					}
					if (nb) {
						this.ystop = true
						bgs[i].iftouched = true
						ifstop = true
						this.jtime = 0
						if (bgs[i].x + bgs[i].w / 2 <= this.x + this.w / 2) {
							this.walkStop = true
							this.walkside = 1
						}
						if (bgs[i].x - bgs[i].w / 2 >= this.x - this.w / 2) {
							this.walkStop = true
							this.walkside = -1
						}
						if (this.state == 1) {
							this.bodyUpD = 0
						}
						if (this.ifjump) {
							this.ifjump = false
						}
						//上下移动
						if (bgs[i].type == 2) {
							this.y += bgs[i].speed
						}
						//左右移动
						if (bgs[i].type == 3) {
							this.x += bgs[i].speed
						}
					}
				}
				//向上顶
				if (bgs[i].x + bgs[i].w / 2 - 5 >= this.x - this.w / 2 && bgs[i].x - bgs[i].w / 2 + 5 <= this.x + this.w / 2 && this.y - this.h / 2 < bgs[i].y + bgs[i].h / 2 - 5 && this.y + this.h / 2 > bgs[i].y - bgs[i].h / 2 + 5) {
					this.vy = -this.vy
					if (this.y < bgs[i].y) {
						this.y -= 5
					} else {
						this.y += 5
					}
				}
				//向左推
				if (bgs[i].x + bgs[i].w / 2 >= this.x - this.w / 2 && bgs[i].x - bgs[i].w / 2 <= this.x + this.w / 2 && this.y - this.h / 2 < bgs[i].y + bgs[i].h / 2 - 5 && this.y + this.h / 2 > bgs[i].y - bgs[i].h / 2 + 5) {
					this.v = 0
					if (this.x < bgs[i].x) {
						this.x -= 5
					} else {
						this.x += 5
					}
				}
			}
			//三角
			if (bgs[i].canstop == 2) {
				//停下
				if (bgs[i].x + bgs[i].w / 2 >= this.x - this.w / 2 && bgs[i].x - bgs[i].w / 2 <= this.x + this.w / 2 && this.y + this.h / 2 >= bgs[i].y - bgs[i].h / 2 && this.y + this.h / 2 <= bgs[i].y + bgs[i].h / 2 + 5) {
					var nb = false
					//步行距离
					this.walkDis = bgs[i].w
					if (bgs[i].t == 1) {
						var inx = Math.abs(this.x - this.w / 2 - bgs[i].x + bgs[i].w / 2)
						var iny = Math.abs(this.y + this.h / 2 - bgs[i].y + bgs[i].h / 2)
						var ind = Math.atan(iny / inx)
					} else {
						var inx = Math.abs(bgs[i].x + bgs[i].w / 2 - this.x - this.w / 2)
						var iny = Math.abs(this.y + this.h / 2 - bgs[i].y + bgs[i].h / 2)
						var ind = Math.atan(iny / inx)
					}
					if (ind >= bgs[i].d) {
						nb = true
					}
					if (nb) {
						if (bgs[i].x + bgs[i].w / 2 <= this.x + this.w / 2) {
							this.walkStop = true
							this.walkside = 1
						}
						if (bgs[i].x - bgs[i].w / 2 >= this.x - this.w / 2) {
							this.walkStop = true
							this.walkside = -1
						}
						this.ystop = true
						ifstop = true
						this.jtime = 0
						if (this.ifjump) {
							this.ifjump = false
						}
						//跑步重置
						this.x -= this.v * this.t
						this.x += this.v * Math.cos(bgs[i].d) * this.t
						this.y += this.v * Math.sin(bgs[i].d) * this.t * bgs[i].t
						if (this.state == 1) {
							this.bodyUpD = 0
						}
					}
					//向上顶
					var ifDing = false
					if (iny >= inx * Math.tan(bgs[i].d) + 5) {
						ifDing = true
					}
					if (ifDing) {
						this.y -= 5
					}
				}
				//向xia顶
				if (bgs[i].x + bgs[i].w / 2 >= this.x - this.w / 2 && bgs[i].x - bgs[i].w / 2 <= this.x + this.w / 2 && this.y - this.h / 2 < bgs[i].y + bgs[i].h / 2 && this.y + this.h / 2 >= bgs[i].y + bgs[i].h / 2 + 5) {
					this.vy = -this.vy
					this.y += 5
				}
				//向左推
				if (this.x + this.w / 2 >= bgs[i].x - bgs[i].w / 2 && this.x + this.w / 2 <= bgs[i].x - bgs[i].w / 2 + 10 && bgs[i].t == 1 && this.y - this.h / 2 < bgs[i].y + bgs[i].h / 2 - 5 && this.y + this.h / 2 > bgs[i].y - bgs[i].h / 2 + 5) {
					this.x -= this.vmax + 1
				}
				//向右推
				if (this.x - this.w / 2 <= bgs[i].x + bgs[i].w / 2 && this.x - this.w / 2 >= bgs[i].x + bgs[i].w / 2 - 10 && bgs[i].t == -1 && this.y - this.h / 2 < bgs[i].y + bgs[i].h / 2 - 5 && this.y + this.h / 2 > bgs[i].y - bgs[i].h / 2 + 5) {
					this.x += this.vmax + 1
				}
			}
		}
		//判断是否继续掉落
		if (!ifstop) {
			this.ystop = false
		}
	}
	this.act = function() {
		//非攻击状态时index归零
		if (this.state != 2) {
			this.actindex = 0
		}
		//空翻判断
		this.backround();
		//动作循环
		if (this.actn > this.commonAttackActionNumber[this.actstate] || this.actn < 1) {
			this.actn = 1
		}
		//行者（英雄）
		if (this.type == 1) {
			//已完成动作后的等待
			if (this.actfinished) {
				this.actin++
				if (this.actin >= 40) {
					this.actin = 0
					this.actn = 1
					this.state = 1
				}
			}
			if (this.state == 2) {
				//普攻
				if (this.actstate == 0) {
					this.weaponhand = 1
					//已完成动作后的等待
					if (!this.actfinished) {
						//动作1
						if (this.actn == 1) {
							//this.v=0
							this.legRD = 0
							this.legLD = 0
							this.legRD2 = 0
							this.legLD2 = 0
							this.bodyX = 0
							this.bodyY = 0
							//挥手
							if (this.actindex < 10) {
								this.armRD = -Math.PI
								this.armRD2 = -Math.PI / 4
								this.weaponD = -Math.PI * 4 / 3
								this.headD = -Math.PI / 12
								this.armLD = Math.PI / 12
							}
							if (this.actindex >= 10 && this.actindex <= 20) {
								this.armRD = -Math.PI + (this.actindex - 10) * Math.PI / 12.5
								this.armRD2 = (this.actindex - 10) * Math.PI / 40 - Math.PI / 4
								this.weaponD = -Math.PI * 4 / 3 + ((this.actindex - 10) * Math.PI / 12.5) * 4 / 3
								this.headD = -Math.PI / 12 + (this.actindex - 10) * Math.PI / 60
								this.armLD = Math.PI / 12 + (this.actindex - 10) * Math.PI / 60
							}
							if (this.actindex == 20) {
								this.attack2(this.dmg * 0.9, this.dmg * 1.1, 120 * this.size, 160 * this.size, this.x + 100 * this.size * this.t, this.y, 2, -3, this.t);
							}
						}
						//动作2
						if (this.actn == 2) {
							this.v = 0
							this.legRD = 0
							this.legLD = 0
							this.legRD2 = 0
							this.legLD2 = 0
							this.bodyX = 0
							this.bodyY = 0
							//上挑
							if (this.actindex < 10) {
								this.armRD = -Math.PI / 5
								this.armRD2 = -Math.PI / 4
								this.weaponD = -Math.PI / 5
								this.headD = Math.PI / 12
								this.armLD = Math.PI / 4
							}
							if (this.actindex >= 10 && this.actindex <= 20) {
								this.armRD = -Math.PI / 5 - (this.actindex - 10) * Math.PI / 12.5
								this.armRD2 = -(this.actindex - 10) * Math.PI / 40 + Math.PI / 4
								this.weaponD = -Math.PI / 5 - (this.actindex - 10) * Math.PI / 12.5
								this.headD = Math.PI / 12 - (this.actindex - 10) * Math.PI / 60
								this.armLD = Math.PI / 4 - (this.actindex - 10) * Math.PI / 60
							}
							if (this.actindex == 20) {
								this.attack2(this.dmg * 0.9, this.dmg * 1.1, 120 * this.size, 160 * this.size, this.x + 100 * this.size * this.t, this.y, -1, -10, this.t, false, 0, true, 4);
							}
						}
						//动作3
						if (this.actn == 3) {
							//转
							if (this.actindex == 0) {
								this.legRD = 0
								this.legLD = 0
								this.legRD2 = 0
								this.legLD2 = 0
								this.bodyX = 0
								this.bodyY = 0
								this.v = 1
								this.rotateSpeed = Math.PI / 40
							}
							if (this.actindex % 25 == 0) {
								this.v = -this.v
								this.t = -this.t
							}
							this.armRD = -Math.PI / 4
							this.weaponD = this.actindex * Math.PI / 12.5
							this.headD = 0
							this.armLD = -Math.PI / 3
							if (this.legRD > Math.PI / 4 || this.legRD < -Math.PI / 4) {
								this.rotateSpeed = -this.rotateSpeed
							}
							this.legRD += this.rotateSpeed
							this.legLD -= this.rotateSpeed
							this.legRD2 = 0
							this.legLD2 = 0
							if ((this.actindex - 12) % 25 == 0) {
								this.attack2(this.dmg * 0.4, this.dmg * 0.5, 140 * this.size, 140 * this.size, this.x + 50 * this.size * this.t, this.y, 2, 4, 0);
							}
						}
						//动作4
						if (this.actn == 4) {
							//劈
							//空翻
							if (this.actindex == 1) {
								this.vy = -32.5 * this.g
								this.v = 0.5
								this.ifjump = true
							}
							if (this.actindex <= 50) {
								this.bodyUpD = this.actindex * Math.PI * 2 / 25
								this.legRD = -Math.PI / 4
								this.legLD = 0
								this.weaponD = Math.PI / 2
								this.armRD = 0
								this.armLD = 0
								if ((this.actindex - 12) % 25 == 0) {
									this.attack2(this.dmg * 0.4, this.dmg * 0.5, 140 * this.size, 140 * this.size, this.x, this.y, 2, 4, 0, false, 0, false);
								}
							} else {
								if (this.actindex <= 60) {
									this.armRD = -Math.PI + (this.actindex - 50) * Math.PI / 12.5
									this.weaponD = -Math.PI + (this.actindex - 50) * Math.PI / 12.5
									this.headD = -Math.PI / 12 + (this.actindex - 50) * Math.PI / 60
									this.armLD = Math.PI / 12 + (this.actindex - 50) * Math.PI / 60
									this.legRD = -Math.PI / 3
									this.legRD2 = Math.PI / 3
									this.legLD = Math.PI / 3
									this.bodyY = 15
									this.trousersD1 = Math.PI / 3
									this.trousersD3 = -Math.PI / 3
									if (this.actindex == 55) {
										this.attack2(this.dmg * 2.5, this.dmg * 3.0, 250 * this.size, 250 * this.size, this.x, this.y, 2, -12, this.t, false, 0, true, 5);
									}
								}
								if (this.actindex >= 66) {
									ifshake = true, shakin = 10
									shakeA = 10
								}
							}
						}

					}
				}
				if (this.actstate == 1) {
					//炽焰闪
					this.vy = 0
					this.weaponhand = 1
					this.v = 15
					this.alp = 0
					this.ifAirStop = true
					this.NoAttack = true
					this.NoSkill = true
					this.NoMove = true
					this.NoJump=true
					this.ifundmged = true
					this.attack2(this.dmg * 3, this.dmg * 3.5, 300 * this.size, 100 * this.size, this.x - 100 * this.t * this.size, this.y, 2, -5, this.t, true, 0, false, 4)
				}
				if (this.actstate == 2) {
					//升龙爆
					this.v = 0
					this.vy = -5 * this.size
					this.ifjump = true
					this.NoAttack = true
					this.NoSkill = true
					this.NoMove = true
					this.ifunbeated = true
					this.ifAirStop = true
					this.NoJump=true
					if (this.actindex % 5 == 1) {
						this.t = -this.t
					}
					if (this.actindex % 10 == 5) {
						this.attack2(this.dmg * 1.2, this.dmg * 1.5, 300 * this.size, 200 * this.size, this.x, this.y, 2, 5, 0, false, 0, true)
					}
					this.weaponD = Math.PI / 2
					this.legLD = 0
					this.legLD2 = 0
					this.legRD = -Math.PI / 4
					this.legRD2 = Math.PI / 3
					this.armLD = -Math.PI / 2
					this.armLD2 = 0
					this.armRD = -Math.PI / 2
					this.armRD2 = 0
					this.trousersD1 = 0
					this.trousersD2 = 0
					this.trousersD3 = -Math.PI / 4
					this.weaponhand = 1
				}
				//烈焰连击
				if (this.actstate == 3) {
					this.NoAttack = true
					this.NoSkill = true
					this.NoMove = true
					this.ifunbeated = true
					this.NoJump=true
					if (this.actindex < 130) {
						this.weaponhand = -2
						if (this.actindex <= 80) {
							this.headD = 0
							this.v = 0
							if (this.actindex <= 20) {
								//抬腿
								this.bodyX = 0
								this.bodyY = 0
								this.bodyUpD = -Math.PI / 160 * this.actindex
								this.legLD = Math.PI / 160 * this.actindex
								this.legLD2 = 0
								this.legRD = -Math.PI / 40 * this.actindex
								this.legRD2 = Math.PI / 3
								this.armLD = Math.PI / 8
								this.armLD2 = -Math.PI * 0.8
								this.armRD = -Math.PI / 8
								this.armRD2 = Math.PI * 0.8
								this.trousersD1 = Math.PI / 160 * this.actindex
								this.trousersD2 = Math.PI / 160 * this.actindex
								this.trousersD3 = Math.PI / 160 * this.actindex - Math.PI / 40 * this.actindex
							} else {
								if (this.actindex <= 30) {
									//震击
									this.bodyX = 0
									this.bodyY = this.h * (this.actindex - 20) / 125
									this.bodyUpD = Math.PI / 80 * (this.actindex - 20) - Math.PI / 8
									this.legLD = Math.PI / 4
									this.legLD2 = 0
									this.legRD = -Math.PI / 2 + Math.PI * (this.actindex - 20) / 60
									this.legRD2 = Math.PI / 3
									if (this.actindex >= 25) {
										this.armLD = Math.PI / 2
										this.armLD2 = Math.PI / 16
										this.armRD = -Math.PI / 2
										this.armRD2 = Math.PI / 16
									}
									if (this.actindex == 25) {
										this.attack2(this.dmg * 0.9, this.dmg * 1.1, 300 * this.size, 200 * this.size, this.x, this.y, 0, -8, this.t, false, 0, true)
									}
									this.trousersD1 = Math.PI / 4
									this.trousersD2 = 0
									this.trousersD3 = -Math.PI / 2 + Math.PI * (this.actindex - 20) / 60
								} else {
									if (this.actindex >= 60) {
										//引拳
										this.bodyX = 0
										this.bodyY = 0
										this.bodyUpD = -Math.PI / 160 * (this.actindex - 60)
										this.legLD = Math.PI / 160 * (this.actindex - 60)
										this.legLD2 = 0
										this.legRD = -Math.PI / 40 * (this.actindex - 60)
										this.legRD2 = Math.PI / 3
										this.armLD = Math.PI / 8
										this.armLD2 = -Math.PI * 0.8
										this.armRD = -Math.PI / 2 + Math.PI / 160 * (this.actindex - 60)
										this.armRD2 = 0
										this.trousersD1 = Math.PI / 160 * (this.actindex - 60)
										this.trousersD2 = Math.PI / 160 * (this.actindex - 60)
										this.trousersD3 = Math.PI / 160 * (this.actindex - 60) - Math.PI / 40 * (this.actindex - 60)
									}
								}
							}
						} else {
							if (this.actindex >= 90) {
								this.headD = -Math.PI / 25
								this.bodyX = 0
								this.bodyY = this.h * 0.1
								this.bodyUpD = Math.PI / 25
								this.legLD = Math.PI / 4
								this.legLD2 = 0
								this.legRD = -Math.PI * 0.4
								this.legRD2 = Math.PI * 0.3
								this.trousersD1 = Math.PI / 4
								this.trousersD2 = 0
								this.trousersD3 = -Math.PI * 0.4
								if ((parseInt((this.actindex - 90) / 10)) % 2 == 0) {
									this.armLD = -Math.PI / 2 - Math.PI / 25
									this.armLD2 = 0
									this.armRD = Math.PI / 8
									this.armRD2 = -Math.PI * 0.7
								} else {
									this.armLD = Math.PI / 8
									this.armLD2 = -Math.PI * 0.7
									this.armRD = -Math.PI / 2 - Math.PI / 25
									this.armRD2 = 0
								}
								if ((this.actindex - 90) % 10 == 0) {
									this.attack2(this.dmg * 0.9, this.dmg * 1.1, 300 * this.size, 200 * this.size, this.x + this.t * 75 * this.size, this.y, 2, -2, this.t, false, 0, false)
								}
							}
						}
					} else {
						if (this.actindex == 130) {
							this.vy = -this.g * 30
							this.ifjump = true
						}
						if (this.actindex <= 145) {
							this.bodyX = 0
							this.bodyY = 0
							this.armLD = -Math.PI / 2 - Math.PI * 2 / 45 * (this.actindex - 130)
							this.armLD2 = 0
							this.armRD = -Math.PI / 2 - Math.PI * 2 / 45 * (this.actindex - 130)
							this.armRD2 = 0
							this.bodyUpD = -Math.PI / 120 * (this.actindex - 130)
							this.legLD = Math.PI / 120 * (this.actindex - 130)
							this.legLD2 = Math.PI / 120 * (this.actindex - 130)
							this.legRD = Math.PI / 120 * (this.actindex - 130)
							this.legRD2 = Math.PI / 120 * (this.actindex - 130)
							this.trousersD1 = Math.PI / 120 * (this.actindex - 130)
							this.trousersD2 = Math.PI / 120 * (this.actindex - 130)
							this.trousersD3 = Math.PI / 120 * (this.actindex - 130)
							this.weaponD = -Math.PI / 2 - Math.PI * 2 / 45 * (this.actindex - 130)
						}
						if (this.actindex >= 175 && this.actindex <= 190) {
							this.bodyX = 0
							this.bodyY = 0
							this.armLD = -Math.PI * 7 / 6 + Math.PI * 5 / 90 * (this.actindex - 175)
							this.armLD2 = 0
							this.armRD = -Math.PI * 7 / 6 + Math.PI * 5 / 90 * (this.actindex - 175)
							this.armRD2 = 0
							this.bodyUpD = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.legLD = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.legLD2 = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.legRD = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.legRD2 = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.trousersD1 = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.trousersD2 = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.trousersD3 = Math.PI / 120 * (this.actindex - 175) - Math.PI / 8
							this.weaponD = -Math.PI * 7 / 6 + Math.PI * 2 / 75 * (this.actindex - 175)
						}
						if (this.actindex > 190 && this.actindex <= 195) {
							this.bodyY = this.h * (this.actindex - 190) * 0.04
							this.weaponD = -Math.PI * 7 / 6 + Math.PI * 2 / 5 + Math.PI * 4 / 75 * (this.actindex - 190)
							this.armLD = -Math.PI / 3 + Math.PI / 25 * (this.actindex - 190)
							this.armLD2 = 0
							this.armRD = -Math.PI / 3 + Math.PI / 15 * (this.actindex - 190)
							this.armRD2 = 0
							this.legLD = Math.PI / 3
							this.legLD2 = 0
							this.legRD = -Math.PI / 2
							this.legRD2 = Math.PI / 2
							this.trousersD1 = Math.PI / 3
							this.trousersD2 = 0
							this.trousersD3 = -Math.PI / 2
							this.weaponSize = (this.actindex - 190) * 0.3 + 1
						}
						if (this.actindex == 195) {
							this.attack2(this.dmg * 4.8, this.dmg * 5.2, 400 * this.size, 200 * this.size, this.x + this.t * 200 * this.size, this.y, 2, -14, this.t, true, 0, false, 8)
						}
						this.headD = 0
						this.weaponhand = -1.5
					}
				}
				if (this.actstate == 4) {
					//狂魔烈焰斩
					this.vy = 0
					this.NoAttack = true
					this.NoSkill = true
					this.NoMove = true
					this.ifunbeated = true
					this.ifAirStop = true
					this.NoJump=true
					this.v = 0
					this.headD = 0
					if (this.actindex <= 160) {
						this.alp = 0
						this.trousersD1 = 0
						this.trousersD3 = 0
						if ((this.actindex + 10) % 20 == 0) {
							this.attack2(this.dmg * 0.7, this.dmg * 0.9, 500 * this.size, 500 * this.size, this.x, this.y + this.h / 2 * this.size - 250 * this.size, 2, 5, 0, false, 0, true,1)
						}
					} else {
						this.alp = 100
						this.bodyX = 0
						if (this.actindex <= 190) {
							this.bodyY = -150 * this.size - (this.actindex - 160) * 10 + (this.actindex - 160) * (this.actindex - 160) / 6 * this.size
							this.headD = -Math.PI / 15
							this.trousersD1 = 0
							this.trousersD3 = -Math.PI / 3
							this.legLD = 0
							this.legLD2 = 0
							this.legRD = -Math.PI / 3
							this.legRD2 = Math.PI / 2
							this.armLD = Math.PI
							this.armRD = -Math.PI
							this.armLD2 = Math.PI * 1 / 5
							this.armRD2 = -Math.PI * 1 / 5
							this.weaponhand = 1
						} else {
							this.headD = Math.PI / 15
							if (this.actindex <= 200) {
								this.bodyY = -300 + (this.actindex - 190) * 30
							} else {
								this.bodyY = 20 * this.size
							}
							this.trousersD1 = -Math.PI / 4
							this.trousersD3 = -Math.PI / 4
							this.legLD = Math.PI / 4
							this.legLD2 = Math.PI / 4
							this.legRD = -Math.PI / 4
							this.legRD2 = Math.PI / 4
							this.armLD = -Math.PI / 3
							this.armRD = -Math.PI / 4
							this.armLD2 = -Math.PI / 6
							this.armRD2 = -Math.PI
							this.weaponhand = 1
						}
						if (this.actindex <= 200) {
							this.weaponD = (this.actindex - 160) * Math.PI * 0.15
						} else {
							this.weaponD = 0
						}
						if (this.actindex == 200) {
							this.attack2(this.dmg * 7.8, this.dmg * 8.2, 500 * this.size, 500 * this.size, this.x, this.y + this.h / 2 * this.size - 250 * this.size, 0, -18, this.t, false, 0, true,6)
							ifshake = true, shakin = 15
							shakeA = 10
						}
					}
				}
			}
		}
		//蘑菇怪
		if (this.type == 2) {
			if (this.state == 2 && !this.actfinished) {
				if (this.actstate == 0) {
					this.v = 0
					if (this.actindex <= 30) {
						this.bodyUpD = 0
						this.bodyY = this.h * 0.3 * this.actindex / 30
					} else {
						this.bodyUpD = (this.actindex - 30) * Math.PI / 120
						this.bodyY = -this.h * 0.3 * (this.actindex - 30) / 30 + this.h * 0.3
					}
					if (this.actindex == 45) {
						this.attack2(this.dmg * 0.9, this.dmg * 1.1, 140 * this.size, 140 * this.size, this.x + 100 * this.size * this.t, this.y, 2, -2, this.t, false, 0, false, 4)
					}
				}
			}
		}
		//百菌仙
		if (this.type == 3) {
			if (this.state == 2 && !this.actfinished) {
				//普攻
				if (this.actstate == 0) {
					this.v = 0
					this.ifunbeated = true
					if (this.actindex <= 10) {
						this.weaponhand = 1
						this.armRD = -Math.PI / 6
						this.armRD2 = 0
						this.armLD = -Math.PI * 2 / 3
						this.armLD2 = 0
						this.weaponD = 0
					}
					if (this.actindex <= 30 && this.actindex >= 10) {
						this.weaponhand = 1
						this.armRD = (this.actindex - 10) * Math.PI / 120 - Math.PI / 6
						this.armRD2 = 0
						this.armLD = (this.actindex - 10) * Math.PI / 60 - Math.PI * 2 / 3
						this.armLD2 = (this.actindex - 10) * Math.PI / 180
						this.weaponD = (this.actindex - 10) * Math.PI / 30
					}
					if (this.actindex > 30) {
						if (this.actindex <= 50) {
							this.weaponhand = -1
							this.bodyUpD = -Math.PI / 160 * (this.actindex - 40)
							this.armLD = -Math.PI / 2
							this.armLD2 = -Math.PI * 4 / 3
							this.armRD = -Math.PI / 2
							this.armRD2 = 0
							this.weaponD = -Math.PI / 2
						} else {
							if (this.actindex <= 55) {
								this.weaponhand = -1
							} else {
								this.weaponhand = 1
							}
							if (this.actindex <= 60) {
								this.bodyUpD = Math.PI / 60 * (this.actindex - 50) - Math.PI / 16
								this.armLD = -Math.PI / 2 + Math.PI / 15 * (this.actindex - 50)
								this.armLD2 = -Math.PI * 4 / 3 + Math.PI * 2 / 15 * (this.actindex - 50)
								this.armRD = -Math.PI / 2 + Math.PI / 15 * (this.actindex - 50)
								this.armRD2 = 0
								this.weaponD = -Math.PI / 2 + Math.PI / 6 * (this.actindex - 50)
							}
						}
					}
					if (this.actindex == 20) {
						this.attack2(this.dmg * 0.9, this.dmg * 1.1, 200 * this.size, 200 * this.size, this.x + 100 * this.size * this.t, this.y, 2, -2, this.t, false, 0, false, 4)
					}
					if (this.actindex == 50) {
						this.attack2(this.dmg * 1.2, this.dmg * 1.5, 200 * this.size, 200 * this.size, this.x + 100 * this.size * this.t, this.y, 5, -3, this.t, false, 0, true, 4)
					}
				}
				//仙剑飞刺
				if (this.actstate == 1) {
					this.ifunbeated = true
					if (this.actindex <= 20) {
						this.v = 0
						this.bodyUpD = -Math.PI / 16
						this.armLD = Math.PI / 2
						this.armLD2 = -Math.PI
						this.armRD = -Math.PI / 6
						this.armRD2 = 0
						this.weaponD = Math.PI / 2
						this.weaponhand = 1
					} else {
						if (this.actindex <= 80) {
							this.v = 0
							if ((this.actindex - 10) % 20 == 0) {
								this.attack2(this.dmg * 0.7, this.dmg * 0.9, 250 * this.size, 200 * this.size, this.x + 100 * this.size * this.t, this.y, 2, -2, this.t, false, 0, false, 3)
							}
							if ((this.actindex - 20) % 20 == 0) {
								this.bodyUpD = -Math.PI / 16
								this.armLD = Math.PI / 2
								this.armLD2 = -Math.PI
								this.armRD = -Math.PI / 6
								this.armRD2 = 0
								this.weaponD = Math.PI / 2
								this.weaponhand = 1
							}
							if ((this.actindex - 10) % 20 == 0) {
								this.bodyUpD = Math.PI / 16
								this.armLD = -Math.PI / 2
								this.armLD2 = 0
								this.armRD = Math.PI / 6
								this.armRD2 = 0
								this.weaponD = Math.PI / 2
								this.weaponhand = 1
							}
						} else {
							if (this.actindex <= 120) {
								this.v = 0
								this.bodyUpD = -Math.PI / 16
								this.armLD = Math.PI / 2
								this.armLD2 = -Math.PI
								this.armRD = -Math.PI / 6
								this.armRD2 = 0
								this.weaponD = Math.PI / 2
								this.weaponhand = 1
							} else {
								this.bodyUpD = Math.PI / 16
								this.armLD = -Math.PI / 2
								this.armLD2 = 0
								this.armRD = Math.PI / 6
								this.armRD2 = 0
								this.weaponD = Math.PI / 2
								this.weaponhand = 1
								this.v = 20
								this.attack2(this.dmg * 1.8, this.dmg * 2.2, 200 * this.size, 200 * this.size, this.x + 100 * this.size * this.t, this.y, 2, -8, this.t, true, 0, true, 20)
							}
						}
					}
				}
				if (this.actstate == 2) {
					this.v = 0
					if (this.actindex % 30 == 0) {
						hs[hs.length] = new H(2, this.x, this.y, 1, 200, 0, 0, 0, 20, 0, 0, 5, [], 2, 10, 10, false, 5)
					}
				}
			}
		}
		if (this.state == 2) {
			//普适性
			if (!this.actfinished) {
				this.actindex++
			}
			var tT = 0
			for (var i = 0; i < this.actstate; i++) {
				tT += this.commonAttackActionNumber[i]
			}
			//alert(tT)
			if (this.actindex >= this.attackDuration[tT + this.actn - 1]) {
				this.actfinished = true
				this.actindex = 0
				this.state = 1
				this.actn++
				//行者
				if (this.type == 1) {
					//烈焰闪
					if (this.actstate == 1) {
						this.alp = 100
						this.v = 0
						this.ifAirStop = false
						this.throughArr = []
						this.NoAttack = false
						this.NoSkill = false
						this.NoMove = false
						this.ifundmged = false
						this.NoJump=false
					}
					//升龙爆
					if (this.actstate == 2) {
						this.alp = 100
						this.v = 0
						this.bodyX = 0
						this.bodyY = 0
						this.ifAirStop = false
						this.throughArr = []
						this.NoAttack = false
						this.NoSkill = false
						this.NoMove = false
						this.ifunbeated = false
						this.NoJump=false
						this.headD = 0
						this.trousersD1 = 0
						this.trousersD3 = 0
					}
					//烈焰连击
					if (this.actstate == 3) {
						this.alp = 100
						this.v = 0
						this.bodyX = 0
						this.bodyY = 0
						this.ifAirStop = false
						this.throughArr = []
						this.NoAttack = false
						this.NoSkill = false
						this.NoMove = false
						this.ifunbeated = false
						this.NoJump=false
						this.headD = 0
						this.trousersD1 = 0
						this.trousersD3 = 0
						this.weaponhand = 1
					}
					//狂魔烈焰斩
					if (this.actstate == 4) {
						this.alp = 100
						this.v = 0
						this.bodyX = 0
						this.bodyY = 0
						this.ifAirStop = false
						this.throughArr = []
						this.NoAttack = false
						this.NoSkill = false
						this.NoMove = false
						this.ifunbeated = false
						this.NoJump=false
						this.headD = 0
						this.trousersD1 = 0
						this.trousersD3 = 0
					}
				}
				//蘑菇怪,百菌仙
				if (this.type == 2 || this.type == 3) {
					this.attackNum++
					if (probability(0.5)) {
						this.t = -this.t
					}
					this.ifAttackFinished = true
				}
				//百菌仙
				if (this.type == 3) {
					this.bodyX = 0
					this.bodyY = 0
					this.ifunbeated = false
					this.throughArr = []
					this.v = 0
				}
			}
		}
	}
	this.borderCheck = function() {
		while (true) {
			if (this.x - this.w / 2 <= 0) {
				this.x += 2
			} else {
				break
			}
		}
		while (true) {
			if (this.x + this.w / 2 >= worldWidth[game - 1]) {
				this.x -= 2
			} else {
				break
			}
		}
		//分割世界自动阻挡
		if (ifThroughLocked) {
			while (true) {
				if (this.x - this.w / 2 <= worldDividedXHome[game-1][dividedWorld][0]) {
					this.x += 2
				} else {
					break
				}
			}
			while (true) {
				if (this.x + this.w / 2 >= worldDividedXHome[game-1][dividedWorld][1]) {
					this.x -= 2
				} else {
					break
				}
			}
			while (true) {
				if (this.y - this.h / 2 <= worldDividedYHome[game-1][dividedWorld][0]) {
					this.y += 2
				} else {
					break
				}
			}
		}
	}
	this.frameCheck = function() {
		if (this.type == 1) {
			if (this.state == 1) {
				if (!this.ystop) {
					this.legRD = -Math.PI / 4
					this.legRD2 = Math.PI / 3
					this.legLD = 0
					this.legLD2 = 0
					this.trousersD1 = 0
					this.trousersD2 = 0
					this.trousersD3 = -Math.PI / 4
				} else {
					if (!this.xmove) {
						this.legLD = 0
						this.legLD2 = 0
						this.legRD = 0
						this.legRD2 = 0
					}
				}
			}
		}
		//被打
		if (!this.ifTouchedGround) {
			if (this.type == 1) {
				if (this.state == 3) {
					this.headF = -1
					this.bodyUpD = -Math.PI / 6
					this.legRD = -Math.PI / 4
					this.legRD2 = Math.PI / 3
					this.legLD = 0
					this.legLD2 = 0
					this.trousersD1 = 0
					this.trousersD2 = 0
					this.trousersD3 = -Math.PI / 4
					this.armLD = Math.PI / 6
					this.armLD2 = 0
					this.armRD = -Math.PI / 3
					this.armRD2 = 0
				} else {
					this.headF = -2
				}
			}
			if (this.type == 2) {
				if (this.state == 3) {
					this.headF = 3
					this.bodyUpD = -Math.PI / 6
				} else {
					this.headF = 2
				}
			}
			if (this.type == 3) {
				if (this.state == 3) {
					this.headF = 5
					this.bodyUpD = -Math.PI / 6
				} else {
					this.headF = 4
				}
			}
		}
	}
	this.bloodpaint = function() {
		if (this.type > 0) {
			if (this.bla > 0) {
				ctx.globalAlpha = this.bla / 100
				ctx.translate(this.x - xPass, this.y - yPass - this.h + 10)
				ctx.fillStyle = "red"
				ctx.fillRect(-50, -5, 100, 10)
				ctx.fillStyle = "lime"
				if (this.life >= 0) {
					if (this.life >= this.blife) {
						ctx.fillRect(-50, -5, 100, 10)
					} else {
						ctx.fillRect(-50, -5, 100 * this.life / this.blife, 10)
					}
				}
				ctx.setTransform(1, 0, 0, 1, 0, 0)
				ctx.globalAlpha = 1
			}
		}
	}
	this.upDate = function() {
		if (this.lifeCut != this.life) {
			if (this.lifeCut >= this.life + this.blife / 80 || this.lifeCut <= this.life - this.blife / 80) {
				if (this.lifeCut >= this.life + this.blife / 80) {
					this.lifeCut -= this.blife / 80
				} else {
					this.lifeCut += this.blife / 80
				}
			} else {
				this.lifeCut = this.life
			}
		}
		if (this.magicCut != this.magic) {
			if (this.magicCut >= this.magic + this.bmagic / 80 || this.magicCut <= this.magic - this.bmagic / 80) {
				if (this.magicCut >= this.magic + this.bmagic / 80) {
					this.magicCut -= this.bmagic / 80
				} else {
					this.magicCut += this.bmagic / 80
				}
			} else {
				this.magicCut = this.magic
			}
		}
		if (this.type == 1) {
			this.blife = Life
			this.bmagic = Magic
			this.lifeback = Lifeback
			this.magicback = Magicback
			this.escape = Escape
			this.defense = Defense
			this.dmg = Dmg
			this.kill = Kill
			this.toughness = Toughness
			this.accurance = Accurance
			this.w = this.bw * this.size
			this.h = this.bh * this.size
			if (level > this.lv) {
				if (hs[0] != undefined) {
					hs[0].relife(1, 1)
				}
			}
			this.skillCostMagic = []
			this.lv = level
			for (var i = 0; i <= 3; i++) {
				var llv = Not0(parseInt((this.lv - i + 3) / 4))
				this.skillCostMagic[i] = Math.round(skillCostMagic[heroType][i][0] + skillCostMagic[heroType][i][1] * llv + skillCostMagic[heroType][i][2] * llv * llv / 2)
			}
		}
	}
	//传送管理
	this.expressCheck = function() {
		if (this.express) {
			this.expressin++
			if (this.expressin >= 50) {
				this.expressin = 0
				this.express = false
			}
		}
		//传送门管理
		if (this.type == -0.3) {
			this.fin++
			if (this.fin >= 15) {
				this.fin = 0
				if (this.frame < 9) {
					this.frame++
				} else {
					this.frame = 0
				}
			}
		}
	}
	//掉落品&传送门
	this.Given = function() {
		if (this.type == -0.3) {
			this.expressDisplay = false
		}
		if (this.type == -0.1 || this.type == -0.2 || this.type == -0.3) {
			for (var i = 0; i < hs.length; i++) {
				if (this.x + this.w / 2 >= hs[i].x - hs[i].w / 2 && this.x - this.w / 2 <= hs[i].x + hs[i].w / 2 && this.y + this.h / 2 >= hs[i].y - hs[i].h / 2 && this.y - this.h / 2 <= hs[i].y + hs[i].h / 2 && i == 0) {
					if (this.type == -0.3) {
						this.expressDisplay = true
						if (hs[i].express) {
							game++
							Initializing(game);
						}
					} else {
						this.canDelete = 1
						if (this.type == -0.1) {
							hs[i].life += this.life
							efs[efs.length] = new Ef(this.x, this.y, 1, this.life, [20, 240, 20])
						}
						if (this.type == -0.2) {
							hs[i].magic += this.life
							efs[efs.length] = new Ef(this.x, this.y, 1, this.life, [0, 160, 240])
						}
					}
				}
			}
		}
	}
	this.draw = function(img, d, r, x, y, w, h, alp, tt, imgx, imgy, ctx, TwiceD, Test) {//绘制部位(图片，旋转角，旋转半径，旋转中心（👉👇右下为正）,宽长,透明度,方向，所绘制图片据图片中点的位置（👉👇右下为正）,2次旋转角,3次半径,3次旋转角)
		ctx.globalAlpha = alp / 100
		//初始化
		if (TwiceD == undefined) {
			TwiceD = 0
		}
		var rr = Math.sqrt(x * x + y * y)//相对整体中心的旋转中心
		var dd = 0
		var t = 1//向右为1
		if (x < 0) {
			t = -1
		}
		var up = 1//向下为1
		if (y < 0) {
			up = -1
		}
		//将单一字符串拼成数组
		if (r[0] == undefined) {
			r = [r]
		}
		if (TwiceD[0] == undefined) {
			TwiceD = [TwiceD]
		}
		//tan90无意义
		if (x != 0 || y != 0) {
			if (up == 1) {
				dd = (Math.PI - Math.atan(Math.abs(x / y))) * t
			} else {
				dd = Math.atan(Math.abs(x / y)) * t
			}
		} else {
			if (x == 0 && y == 0) {
			} else {
				if (x == 0) {
					if (up == 1) {
						dd = Math.PI
					} else {
						dd = 0
					}
				}
				if (y == 0) {
					dd = Math.PI * t / 2
				}
			}
		}
		var d2 = 0
		var ddd = 0
		var rrr = 0
		var extraD = 0
		var Direction = 1
		for (var i = 0; i < r.length; i++) {
			t = 1//向右为1
			if (x < 0) {
				t = -1
			}
			up = 1//向下为1
			if (y < 0) {
				up = -1
			}
			d2 = Math.abs(DChange(Math.PI + dd - TwiceD[i]))
			rrr = Math.sqrt(rr * rr + r[i] * r[i] - 2 * r[i] * rr * Math.cos(d2))//余弦定理
			extraD = Math.abs(Math.acos((rr * rr + rrr * rrr - r[i] * r[i]) / (2 * rr * rrr)))//余弦定理
			Direction = 1
			if (t == 1) {
				if (TwiceD[i] > 0) {
					if (TwiceD[i] <= Math.abs(dd)) {
						Direction = -1
					}
				} else {
					if (-TwiceD[i] <= Math.PI - Math.abs(dd)) {
						Direction = -1
					}
				}
			} else {
				if (TwiceD[i] > 0) {
					if (TwiceD[i] >= Math.PI + dd) {
						Direction = -1
					}
				} else {
					if (TwiceD[i] <= dd) {
						Direction = -1
					}
				}
			}
			ddd = DChange(dd + extraD * Direction)
			dd = ddd
			rr = rrr
			x = Math.sin(dd) * rr
			y = -Math.cos(dd) * rr
		}
		ddd = DChange(ddd + this.bodyUpD)
		ctx.translate(this.x + this.t * Math.sin(ddd) * rrr - xPass + this.bodyX, this.y - Math.cos(ddd) * rrr - yPass + this.bodyY);
		ctx.scale(tt, 1)
		ctx.rotate(d + this.bodyUpD);
		ctx.drawImage(img, -w / 2 + imgx, -h / 2 + imgy, w, h)
		ctx.globalAlpha = 1
		ctx.setTransform(1, 0, 0, 1, 0, 0)
	}
	this.allPaint = function(ctx) {
		ctx.font = "50px 黑体"
		ctx.fillStyle = "white"
		//ctx.fillText(this.ystop,300, 300)
		//孙悟空
		if (this.type == 1) {
			//技能（人物身后）
			if (this.actstate == 4) {
				if (this.actindex >= 195) {
					ctx.translate(this.x - xPass, this.y - yPass - this.h / 2 - 230 * this.size)
					if (this.actindex < 225) {
						ctx.drawImage(action[0][6][3 + parseInt((this.actindex - 195) / 10)], -300 * this.size, 0, 300 * this.size, 400 * this.size)
						ctx.drawImage(action[0][6][3 + parseInt((this.actindex - 195) / 10)], -150 * this.size, 0, 300 * this.size, 400 * this.size)
						ctx.drawImage(action[0][6][3 + parseInt((this.actindex - 195) / 10)], 0 * this.size, 0, 300 * this.size, 400 * this.size)
					} else {
						ctx.globalAlpha = 1 + (225 - this.actindex) / 25
						ctx.drawImage(action[0][6][5], -380 * this.size, 0, 320 * this.size, 450 * this.size)
						ctx.drawImage(action[0][6][5], -160 * this.size, 0, 320 * this.size, 450 * this.size)
						ctx.drawImage(action[0][6][5], 50 * this.size, 0, 320 * this.size, 450 * this.size)
					}
					ctx.globalAlpha = 1
					ctx.setTransform(1, 0, 0, 1, 0, 0)
				}
			}
			//右胳膊
			this.draw(h[1][4][-1][1], this.armRD, 0, 18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
			//袖子
			this.draw(h[1][4][this.clothF][1], this.armRD, 0, 18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
			//小臂
			this.draw(h[1][4][-1][2], this.armRD + this.armRD2, 28 * this.size, 18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 0, ctx, DChange(this.armRD + Math.PI))//默认旋转起始面向上，手臂向下
			//武器(右手)
			if (this.weaponhand == 1) {
				this.draw(h[1][6][this.weaponF], this.weaponD, [25 * this.size, 20 * this.size], 15 * this.size, -6 * this.size, 150 * this.size, 150 * this.size, this.alp, this.t, 0, 0, ctx, [DChange(this.armRD + Math.PI), DChange(this.armRD2 + this.armRD + Math.PI)])
			}
			//右腿
			this.draw(h[1][5][-1], this.bodyDownD + this.legRD, 0, 10 * this.size, 35 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 17 * this.size, ctx)
			//小腿
			this.draw(h[1][5][-2], this.bodyDownD + this.legRD + this.legRD2, 25 * this.size, 10 * this.size, 35 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 0, ctx, DChange(this.legRD + this.bodyDownD + Math.PI))
			//裤子
			this.draw(h[1][5][this.trousersF], this.bodyDownD + this.legRD, 0, 10 * this.size, 35 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 0, ctx)
			//左腿
			this.draw(h[1][5][-1], this.bodyDownD + this.legLD, 0, -10 * this.size, 35 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 17 * this.size, ctx)
			//小腿
			this.draw(h[1][5][-2], this.bodyDownD + this.legLD + this.legLD2, 25 * this.size, -10 * this.size, 35 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 0, ctx, DChange(this.legLD + this.bodyDownD + Math.PI))
			//裤子
			this.draw(h[1][5][this.trousersF], this.bodyDownD + this.legLD, 0, -10 * this.size, 35 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 0, ctx)
			//下衣
			//1
			this.draw(h[1][3][this.trousersF][1], this.bodyDownD + this.trousersD1, 0, -15 * this.size, 35 * this.size, 70 * this.size, 70 * this.size, this.alp, this.t, 0, 0, ctx)
			//3
			this.draw(h[1][3][this.trousersF][3], this.bodyDownD + this.trousersD3, 0, 15 * this.size, 35 * this.size, 70 * this.size, 70 * this.size, this.alp, this.t, 0, 0, ctx)
			//2
			this.draw(h[1][3][this.trousersF][2], this.bodyDownD + this.trousersD2, 0, 0, 35 * this.size, 70 * this.size, 70 * this.size, this.alp, this.t, 0, 0, ctx)
			//武器(左手衣服下)
			if (this.weaponhand == -1) {
				this.draw(h[1][6][this.weaponF], this.weaponD, [25 * this.size, 20 * this.size], -15 * this.size, -6 * this.size, 150 * this.size, 150 * this.size, this.alp, this.t, 0, 0, ctx, [DChange(this.armLD + Math.PI), DChange(this.armLD2 + this.armLD + Math.PI)])
			}
			//上衣
			this.draw(h[1][2][this.clothF], 0, 0, 0, 8 * this.size, 60 * this.size, 60 * this.size, this.alp, this.t, 0, 0, ctx)
			//武器(左手衣服上)
			if (this.weaponhand == -1.5) {
				this.draw(h[1][6][this.weaponF], this.weaponD, [25 * this.size, 20 * this.size], -15 * this.size, -6 * this.size, 150 * this.size * this.weaponSize, 150 * this.size * this.weaponSize, this.alp, this.t, 0, 60 * this.size * this.weaponSize, ctx, [DChange(this.armLD + Math.PI), DChange(this.armLD2 + this.armLD + Math.PI)])
			}
			//头
			this.draw(h[1][1][-3], this.headD, 0, 0, -15 * this.size, 75 * this.size, 75 * this.size, this.alp, this.t, 0, -37.5 * this.size, ctx, 0)
			this.draw(h[1][1][this.headF], this.headD, 0, 0, -15 * this.size, 75 * this.size, 75 * this.size, this.alp, this.t, 0, -37.5 * this.size, ctx, 0)
			this.draw(h[1][1][-4], this.headD, 0, 0, -15 * this.size, 75 * this.size, 75 * this.size, this.alp, this.t, 0, -37.5 * this.size, ctx, 0)
			//头饰
			this.draw(h[1][1][this.headWearF], this.headD, 0, 0, -15 * this.size, 75 * this.size, 75 * this.size, this.alp, this.t, 0, -37.5 * this.size, ctx, 0)
			//左胳膊
			this.draw(h[1][4][-1][1], this.armLD, 0, -18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
			//袖子
			this.draw(h[1][4][this.clothF][1], this.armLD, 0, -18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
			//小臂
			this.draw(h[1][4][-1][2], this.armLD + this.armLD2, 28 * this.size, -18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 0, ctx, DChange(this.armLD + Math.PI))
			//披风
			//ctx.drawImage(h[1][2][-1], -30, -30, 60, 60)
			//动作特效
			if (this.state == 2) {
				//普攻
				if (this.actstate == 0) {
					if (this.actn == 1) {
						var fn = 0
						if (this.actindex <= 10) {
							fn = 0
						} else {
							fn = Math.round((this.actindex - 10) / 5)
							ctx.translate(this.x - xPass + 100 * this.t * this.size + this.t * this.bodyX, this.y - yPass + this.bodyY)
							ctx.scale(this.t, 1)
							if (action[0][1][fn] != undefined) {
								ctx.drawImage(action[0][1][fn], -100 * this.size, -100 * this.size, 200 * this.size, 200 * this.size)
							}
							ctx.setTransform(1, 0, 0, 1, 0, 0)
						}
					}
					if (this.actn == 2) {
						var fn = 0
						if (this.actindex <= 10) {
							fn = 0
						} else {
							fn = Math.round((this.actindex - 10) / 4)
							ctx.translate(this.x - xPass + 100 * this.size * this.t + this.t * this.bodyX, this.y - yPass + this.bodyY)
							ctx.scale(this.t, 1)
							if (action[0][2][fn] != undefined) {
								ctx.drawImage(action[0][2][fn], -100 * this.size, -100 * this.size, 200 * this.size, 200 * this.size)
							}
							ctx.setTransform(1, 0, 0, 1, 0, 0)
						}
					}
					if (this.actn == 3) {
						ctx.translate(this.x - xPass + 50 * this.size * this.t + this.t * this.bodyX, this.y - yPass + this.bodyY + 30)
						ctx.scale(this.t, 1)
						ctx.rotate(this.actindex * 2 / 25 * Math.PI)
						ctx.drawImage(action[0][3][0], -100 * this.size, -100 * this.size, 200 * this.size, 200 * this.size)
						ctx.setTransform(1, 0, 0, 1, 0, 0)
					}
					if (this.actn == 4) {
						if (this.actindex <= 50) {
							ctx.translate(this.x - xPass + this.t * this.bodyX, this.y - yPass + this.bodyY)
							ctx.scale(this.t, 1)
							ctx.rotate(this.actindex * 2 / 25 * Math.PI)
							ctx.drawImage(action[0][3][0], -100 * this.size, -100 * this.size, 200 * this.size, 200 * this.size)
							ctx.setTransform(1, 0, 0, 1, 0, 0)
						} else {
							var fn = 0
							fn = Math.round((this.actindex - 50) / 5)
							ctx.translate(this.x - xPass + this.t * this.bodyX, this.y - yPass + this.bodyY)
							ctx.scale(this.t, 1)
							if (action[0][1][fn] != undefined) {
								ctx.drawImage(action[0][4][fn], -150 * this.size, -180 * this.size, 300 * this.size, 300 * this.size)
							}
							ctx.setTransform(1, 0, 0, 1, 0, 0)
						}
					}
				}
				//技能
				if (this.actstate == 1) {
					var fn = 0
					fn = Math.round(this.actindex / 5)
					ffn = fn % 4
					ctx.translate(this.x - xPass + this.t * this.bodyX, this.y - yPass + this.bodyY)
					ctx.scale(this.t, 1)
					if (action[0][5][ffn] != undefined) {
						ctx.drawImage(action[0][5][ffn], -250 * this.size, -50 * this.size, 300 * this.size, 100 * this.size)
					}
					ctx.setTransform(1, 0, 0, 1, 0, 0)
				}
				if (this.actstate == 2) {
					var fn = 0
					fn = Math.round(this.actindex / 3)
					ffn = fn % 4
					ctx.translate(this.x - xPass + this.t * this.bodyX, this.y - yPass + this.bodyY)
					if (action[0][7][ffn] != undefined) {
						ctx.drawImage(action[0][7][ffn], -150 * this.size, -100 * this.size, 300 * this.size, 200 * this.size)
					}
					ctx.setTransform(1, 0, 0, 1, 0, 0)
				}
				if (this.actstate == 4) {
					if (this.actindex <= 160) {
						var skillt = (parseInt(this.actindex / 10)) % 2
						if (skillt == 0) {
							skillt = -1
						}
						ctx.translate(this.x - xPass, this.y - yPass + this.h / 2 - 250 * this.size)
						var fn = parseInt((this.actindex % 10) / 3.4)
						ctx.scale(skillt, 1)
						var Dd = 0
						if (this.actindex > 40 && this.actindex <= 80) {
							Dd = -Math.PI / 4
						}
						if (this.actindex > 80 && this.actindex <= 120) {
							Dd = -Math.PI / 2
						}
						if (this.actindex > 120 && this.actindex <= 140) {
							Dd = -Math.PI * 3 / 4
						}
						ctx.rotate(Dd)
						if (action[0][6][fn] != undefined) {
							ctx.drawImage(action[0][6][fn], -250 * this.size, -250 * this.size, 500 * this.size, 500 * this.size)
						}
					} else {
						//武器(右手)
						if (this.weaponhand == 1) {
							this.draw(h[1][6][this.weaponF], this.weaponD, [25 * this.size, 20 * this.size], 15 * this.size, -6 * this.size, 150 * this.size, 150 * this.size, this.alp, this.t, 0, 0, ctx, [DChange(this.armRD + Math.PI), DChange(this.armRD2 + this.armRD + Math.PI)])
						}
						//左胳膊
						this.draw(h[1][4][-1][1], this.armLD, 0, -18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
						//袖子
						this.draw(h[1][4][this.clothF][1], this.armLD, 0, -18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
						//小臂
						this.draw(h[1][4][-1][2], this.armLD + this.armLD2, 28 * this.size, -18 * this.size, -6 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 0, ctx, DChange(this.armLD + Math.PI))

						if (this.actindex < 190) {
							ctx.translate(this.x - xPass, this.y - yPass + this.bodyY - this.h * 1.2 / 2)
							ctx.fillStyle = "yellow"
							ctx.beginPath();
							ctx.arc(0, 0, (200 - this.actindex) * 2, 0, Math.PI * 2, true)
							ctx.closePath();
							ctx.fill();
						}
					}
					ctx.setTransform(1, 0, 0, 1, 0, 0)
				}
			}
			//ctx.fillRect(this.x-xPass-3,this.y-yPass-3,6,6)
			//ctx.fillText(this.NoAttack, 300, 300)
		}
		//蘑菇怪
		if (this.type == 2) {
			if (this.state != 2) {
				//柄
				this.draw(e[1][1], 0, 0, 0, 20 * this.size, 80 * this.size, 80 * this.size, this.alp, this.t, 0, 0, ctx)
				//伞帽
				this.draw(e[1][0], this.headD, 0, 0, -20 * this.size, 140 * this.size, 140 * this.size, this.alp, this.t, 0, 0, ctx)
				//眼睛
				this.draw(e[1][this.headF], this.headD, 0, 5 * this.size, -25 * this.size, 90 * this.size, 90 * this.size, this.alp, this.t, 0, 0, ctx)
			} else {
				if (this.actstate == 0) {
					var skillsize = 1
					if (this.actindex <= 30) {
						skillsize = 1 - this.actindex / 50
					} else {
						skillsize = 0.6 + (this.actindex - 30) / 50
					}
					//柄
					this.draw(e[1][1], 0, 0, 0, 25 * this.size * skillsize, 80 * this.size, 80 * this.size * skillsize, this.alp, this.t, 0, 0, ctx)
					//伞帽
					this.draw(e[1][0], this.headD, 0, 0, -20 * this.size * skillsize, 140 * this.size, 140 * this.size * skillsize, this.alp, this.t, 0, 0, ctx)
					//眼睛
					this.draw(e[1][this.headF], this.headD, 0, 5 * this.size, -25 * this.size * skillsize, 90 * this.size, 90 * this.size * skillsize, this.alp, this.t, 0, 0, ctx)
				}
			}
			//ctx.fillStyle="white"
			//ctx.fillText(this.attackFinishedin, 300, 300)
		}
		//百菌仙
		if (this.type == 3) {
			if (this.weaponhand == -1) {
				this.draw(e[2][11], this.weaponD, [37 * this.size, 8 * this.size], -15 * this.size, -10 * this.size, 50 * this.size, 150 * this.size, this.alp, this.t, 0, -60 * this.size, ctx, [DChange(Math.PI + this.armLD), DChange(Math.PI + this.armLD + this.armLD2)])
			}
			//头发
			this.draw(e[2][2], this.hairD1, 0, 17 * this.size, -70 * this.size, 50 * this.size, 100 * this.size, this.alp, this.t, 0, 40 * this.size, ctx)
			//头发
			this.draw(e[2][3], this.hairD3, 0, -38 * this.size, -80 * this.size, 40 * this.size, 70 * this.size, this.alp, this.t, 0, 28 * this.size, ctx)
			//右手
			this.draw(e[2][10], this.armRD + this.armRD2, 37 * this.size, 15 * this.size, -10 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 0, ctx, DChange(Math.PI + this.armRD))
			//右胳膊
			this.draw(e[2][9], this.armRD, 0, 15 * this.size, -10 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 20 * this.size, ctx)
			//裙子
			this.draw(e[2][7], 0, 0, -4 * this.size, 65 * this.size, 70 * this.size, 70 * this.size, this.alp, this.t, 0, 0, ctx)
			this.draw(e[2][8], this.trousersD3, 0, 6 * this.size, 40 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 25 * this.size, ctx)
			this.draw(e[2][13], this.trousersD1, 0, -15 * this.size, 40 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
			this.draw(e[2][14], this.trousersD2, 0, 13 * this.size, 40 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 15 * this.size, ctx)
			//身体
			this.draw(e[2][6], 0, 0, 0, 10 * this.size, 80 * this.size, 80 * this.size, this.alp, this.t, 0, 0, ctx)
			//头
			this.draw(e[2][1], 0, 0, 0, -130 * this.size, 90 * this.size, 90 * this.size, this.alp, this.t, 0, 80 * this.size, ctx)
			//眼睛
			this.draw(e[2][this.headF], 0, 0, 0, -130 * this.size, 90 * this.size, 90 * this.size, this.alp, this.t, 0, 80 * this.size, ctx)
			//武器
			if (this.weaponhand == 1) {
				this.draw(e[2][11], this.weaponD, [37 * this.size, 8 * this.size], -15 * this.size, -10 * this.size, 50 * this.size, 150 * this.size, this.alp, this.t, 0, -60 * this.size, ctx, [DChange(Math.PI + this.armLD), DChange(Math.PI + this.armLD + this.armLD2)])
			}
			//左手
			this.draw(e[2][12], this.armLD + this.armLD2, 37 * this.size, -15 * this.size, -10 * this.size, 40 * this.size, 40 * this.size, this.alp, this.t, 0, 0, ctx, DChange(Math.PI + this.armLD))
			//左胳膊
			this.draw(e[2][9], this.armLD, 0, -15 * this.size, -10 * this.size, 50 * this.size, 50 * this.size, this.alp, this.t, 0, 20 * this.size, ctx)
			//头发
			this.draw(e[2][2], this.hairD2, 0, -17 * this.size, -70 * this.size, 50 * this.size, 100 * this.size, this.alp, this.t, 0, 40 * this.size, ctx)
			//帽子
			this.draw(e[2][0], 0, 0, -2 * this.size, -138 * this.size, 90 * this.size, 90 * this.size, this.alp, this.t, 0, 80 * this.size, ctx)
			//ctx.fillStyle="white"
			//ctx.fillText(this.attackFinishedin, 300, 300)
			//ctx.fillText(this.attackNum, 300, 300)
		}
		//补给品
		if (this.type <= 0) {
			if (this.type != -0.3) {
				ctx.drawImage(this.img, this.x - this.w / 2 - xPass, this.y - this.h / 2 - yPass, this.w, this.h)
			} else {
				//传送门
				var hang = parseInt(this.frame / 4)//行
				var lie = this.frame % 4
				ctx.drawImage(this.img, lie * 256, hang * 287, 256, 287, this.x - 256 / 2 - xPass, this.y - 287 / 2 - yPass, 256, 287)
				if (this.expressDisplay) {
					ctx.fillStyle = "black"
					ctx.fillRect(this.x - 30 - xPass, this.y - 150 - yPass, 60, 60)
					ctx.fillStyle = "white"
					ctx.fillRect(this.x - 30 - xPass + 5, this.y - 150 - yPass + 5, 50, 50)
					ctx.font = "60px Consolas"
					ctx.fillStyle = "black"
					ctx.fillText("F", this.x - 30 - xPass + 15, this.y - 150 - yPass + 50)
				}
			}
		}
	}
	//被打恢复
	this.beatenBack = function() {
		this.actfinished =true
		this.beatenin++
		this.x += this.t * this.beatenv
		if (this.ifdown && this.ystop && !this.ifTouchedGround && this.beatenin >= 5) {
			this.ifTouchedGround = true
		}
		if (this.ifdown && this.ifTouchedGround) {
			//跌倒
			this.fallindex++
			this.downindex++
			if (this.downindex <= 60) {
				if (this.bodyUpD >= -Math.PI / 2) {
					this.bodyUpD = -this.fallindex * Math.PI / 40
					this.bodyY = this.fallindex * this.h / 40
				}
			} else {
				if (this.bodyUpD <= 0) {
					this.bodyUpD = -(60 - this.fallindex) * Math.PI / 40 - Math.PI / 2
					this.bodyY = (60 - this.fallindex) * this.h / 40 + this.h / 2
				}
			}
			if (this.downindex == 60) {
				this.vy = -30 * this.g
				this.ifjump = true
			}
			this.beatenv = 0
			if (this.downindex >= 100) {
				this.downindex = 0
				this.ifdown = false
				this.fallindex = 0
				this.state = 1
				this.beatenin = 0
				this.fallindex = 0
				this.bodyY = 0
				this.bodyX = 0
				this.ifTouchedGround = false
				//攻击或是退让
				if (probability(0.5)) {
					this.ifAttackFinished = true
					this.attackFinishedin = 0
				} else {
					this.ifAttackFinished = false
				}
			}
		}
		if (this.beatenin >= 30) {
			if (this.ystop && !this.ifdown) {
				this.state = 1
				this.beatenin = 0
				this.beatenAboveindex = 0
				this.fallindex = 0
				this.bodyY = 0
				this.bodyX = 0
				this.ifTouchedGround = false
				//攻击或是退让
				if (probability(0.5)) {
					this.ifAttackFinished = true
					this.attackFinishedin = 0
				} else {
					this.ifAttackFinished = false
				}
			}
		}
	}
	//死亡前奏
	this.dying = function() {
		this.dyingindex++
		this.ifundmged = true
		if (this.dyingindex <= 30) {
			this.bodyUpD = this.dyingindex * Math.PI / 60 * this.t
			this.bodyY = this.h / 2 * this.dyingindex / 30
		}
		if (this.ystop) {
			if (this.beatenv >= -this.miu && this.beatenv <= this.miu) {
				this.beatenv = 0
			} else {
				if (this.beatenv < 0) {
					this.beatenv += this.miu
				} else {
					this.beatenv -= this.miu
				}
			}
		}
		if (this.dyingindex > 50) {
			if (this.alp >= 1.5) {
				this.alp -= 1.5
			} else {
				this.canDelete = 1
				//掉宝
				if (this.team != 1) {
					if (hs[0] != undefined) {
						//人物未死亡
						if (this.type == 2) {
							if (probability(treasureProbability)) {
								var qqq = Math.round(Math.random())
								switch(qqq) {
									case 0:
										//血瓶
										hs[hs.length] = new H(-0.1, this.x, this.y, 1, Math.round(Math.random() * hs[0].blife / 15 + hs[0].blife * 5 / 15))
										break
									case 1:
										//魔瓶
										hs[hs.length] = new H(-0.2, this.x, this.y, 1, Math.round(Math.random() * hs[0].bmagic / 15 + hs[0].bmagic * 5 / 15))
										break
								}
							}
						}
					}
					//经验
					exp += this.expGain
				}
			}
		}
		this.x += this.t * this.beatenv
	}
	//复活
	this.relife = function(lf, mg) {//复活百分比
		this.life = this.blife * lf
		this.magic = this.bmagic * mg
	}
	this.AllDChange = function() {
		this.armLD = DChange(this.armLD)
		this.armLD2 = DChange(this.armLD2)
		this.armRD = DChange(this.armRD)
		this.armRD2 = DChange(this.armRD2)
		this.headD = DChange(this.headD)
		this.legLD = DChange(this.legLD)
		this.legLD2 = DChange(this.legLD2)
		this.legRD = DChange(this.legRD)
		this.legRD2 = DChange(this.legRD2)
		this.trousersD1 = DChange(this.trousersD1)
		this.trousersD2 = DChange(this.trousersD2)
		this.trousersD3 = DChange(this.trousersD3)
		this.weaponD = DChange(this.weaponD)
	}
	this.sizeCheck = function() {
		this.w = this.bw * this.size
		this.h = this.bh * this.size
	}
	this.heroDetailPaint = function() {//英雄战斗信息
		if (this.type == 1 && this.detailPaint[0] && this.team == 1) {
			//血量
			ctx.strokeStyle = "black"
			ctx.lineWidth = 2
			ctx.strokeRect(130, 10, 250, 20);
			ctx.fillStyle = "rgba(0,0,0,0.7)"
			ctx.fillRect(130, 10, 250, 20)
			ctx.fillStyle = "rgba(250,50,50,1)"
			if (this.life <= this.blife) {
				ctx.fillRect(130, 10, 250 * this.lifeCut / this.blife, 20)
			} else {
				ctx.fillRect(130, 10, 250, 20)
			}
			ctx.font = "20px 幼圆"
			ctx.fillStyle = "rgba(255,255,255,1)"
			ctx.fillText("生命：       " + this.life + "/" + this.blife, 135, 28)
			//魔法值
			ctx.strokeStyle = "black"
			ctx.lineWidth = 2
			ctx.strokeRect(130, 40, 250, 20);
			ctx.fillStyle = "rgba(0,0,0,0.7)"
			ctx.fillRect(130, 40, 250, 20)
			ctx.fillStyle = "rgba(20,150,250,1)"
			if (this.magic <= this.bmagic) {
				ctx.fillRect(130, 40, 250 * this.magicCut / this.bmagic, 20)
			} else {
				ctx.fillRect(130, 40, 250, 20)
			}
			ctx.font = "20px 幼圆"
			ctx.fillStyle = "rgba(255,255,255,1)"
			ctx.fillText("魔法：       " + this.magic + "/" + this.bmagic, 135, 58)
			//经验值
			ctx.strokeStyle = "black"
			ctx.lineWidth = 2
			ctx.strokeRect(130, 70, 250, 20);
			ctx.fillStyle = "rgba(0,0,0,0.7)"
			ctx.fillRect(130, 70, 250, 20)
			ctx.fillStyle = "rgba(250,200,0,1)"
			if (exp <= expmax) {
				ctx.fillRect(130, 70, 250 * exp / expmax, 20)
			} else {
				ctx.fillRect(130, 70, 250, 20)
			}
			ctx.font = "20px 幼圆"
			ctx.fillStyle = "rgba(255,255,255,1)"
			ctx.fillText("经验：       " + exp + "/" + expmax, 135, 88)
			//标识
			
		}
	}
	this.checkSelfProtection = function() {//自我检查保护
		if (this.protectindex >= this.protectmax) {
			this.protectindex = 0
			this.eHome[this.eHome.length] = 1
			this.eIndex[this.eIndex.length] = 0
			this.eTime[this.eTime.length] = 300
			this.eIfForever[this.eIfForever.length] = false
			this.eDetail[this.eDetail.length] = 0
			this.eImage[this.eImage.length] = 0
		}
	}
	this.allEffectionWork = function() {//效果累加器
		for (var i = 0; i < this.eHome.length; i++) {
			if (!this.eIfForever[i]) {
				this.eIndex[i]++
				if (this.eIndex[i] >= this.eTime[i]) {
					this.eHome.splice(i, 1)
					this.eIndex.splice(i, 1)
					this.eTime.splice(i, 1)
					this.eIfForever.splice(i, 1)
					this.eDetail.splice(i, 1)
					this.eImage.splice(i, 1)
				}
			}
		}
	}
	this.allEffectionDisplay = function() {//效果实现器
		//原本效果
		this.ifAirStop = false
		this.NoAttack = false
		this.NoSkill = false
		this.NoMove = false
		this.NoJump=false
		this.ifunbeated = false
		this.ifundmged =false
		this.ifunbeated = false
		this.alp = 100
		for (var i = 0; i < this.eHome.length; i++) {
			if (this.eHome[i] == 1) {
				//无敌
				this.alp = 50
				this.ifundmged = true
			}
		}
	}
	this.attack2 = function(dmgmax, dmgmin, ww, hh, x, y, xv, yv, t, ifthrough, ifdrink, ifbeaten, PPlus) {//矩形攻击区域(xv:被打获得速度，攻击方向)ifthrough是否穿透, ifdrink吸血参数,ifbeaten是否击倒
		if (xv == undefined) {
			xv = 0
		}
		if (yv == undefined) {
			yv = 0
		}
		if (t == undefined) {
			t = 1
		}
		var ifattrack = false//是否吸引
		if (t == 0) {
			ifattrack = true
		}
		if (ifthrough == undefined) {//是否贯穿
			ifthrough = false
		}
		if (ifdrink == undefined) {//是否吸血
			ifdrink = 0
		}
		if (ifbeaten == undefined) {//是否击倒
			ifbeaten = false
		}
		if (PPlus == undefined) {//增加保护值
			PPlus = 2
		}
		var ifAccurance = false//是否命中
		var dmgg = Math.random(dmgmax - dmgmin) + dmgmin
		for (var i = 0; i < hs.length; i++) {
			var dmg1 = Not0(Math.round((dmgg - hs[i].defense) * (Math.random() * 0.5 + 1.5))), dmg2 = Not0(Math.round(dmgg - hs[i].defense))
			if (x + ww / 2 >= hs[i].x - hs[i].w / 2 && x - ww / 2 <= hs[i].x + hs[i].w / 2 && y + hh / 2 >= hs[i].y - hs[i].h / 2 && y - hh / 2 <= hs[i].y + hs[i].h / 2) {
				//在攻击范围内
				if (hs[i].team != this.team && hs[i].type > 0) {
					//确保不是友军
					//是否贯穿
					var ifHit = true
					if (ifthrough && this.throughArr.indexOf(i) != -1) {
						ifHit = false
					}
					//是否攻击
					if (ifHit) {
						if (!hs[i].ifundmged) {
							//非无敌状态
							if (!probability(hs[i].escape / this.accurance)) {
								//未闪避
								if (!probability(hs[i].toughness / this.kill)) {
									//暴击
									hs[i].life -= dmg1
									efs[efs.length] = new Ef(hs[i].x, hs[i].y, 1, "暴击  " + dmg1, [255, 0, 0])
									if (ifdrink > 0) {
										this.life += Math.round(ifdrink * dmg1)
										efs[efs.length] = new Ef(this.x, this.y, 1, Math.round(ifdrink * dmg1), [20, 240, 20])
									}
								} else {
									hs[i].life -= dmg2
									efs[efs.length] = new Ef(hs[i].x, hs[i].y, 1, dmg2, [255, 255, 120])
									if (ifdrink > 0) {
										this.life += Math.round(ifdrink * dmg2)
										efs[efs.length] = new Ef(this.x, this.y, 1, Math.round(ifdrink * dmg2), [20, 240, 20])
									}
								}
								hs[i].protectindex += PPlus
								ifAccurance = true//命中
								if (!hs[i].ifunbeated) {
									//非霸体状态
									hs[i].state = 3
									hs[i].beatenin = 0
									if (ifbeaten) {
										hs[i].downindex = 0
										hs[i].fallindex = 0
										hs[i].ifdown = true
									} else {
										if (hs[i].ifdown) {
											hs[i].downindex = 0
											hs[i].fallindex = 0
										}
									}
									hs[i].bodyX = 0
									hs[i].bodyY = 0
									hs[i].ifTouchedGround = false
									hs[i].ifjump = true
									if (ifattrack) {
										if (hs[i].x > x) {
											hs[i].beatenv = -xv * hs[i].t
										} else {
											hs[i].beatenv = xv * hs[i].t
										}
										if (hs[i].y > y) {
											hs[i].vy = -yv
										} else {
											hs[i].vy = yv
										}
									} else {
										hs[i].beatenv = xv * t * hs[i].t
										hs[i].vy = yv
									}
									hs[i].ifAirStop = false
								}//攻击后增加贯穿项目
								if (ifthrough) {
									this.throughArr[this.throughArr.length] = i
								}
							} else {
								efs[efs.length] = new Ef(hs[i].x, hs[i].y, 1, "闪避", [180, 180, 180])
							}
						} else {
							//efs[efs.length] = new Ef(hs[i].x, hs[i].y, 1, "无敌", [255, 255, 255])
						}
					}
				}
			}
		}
		return ifAccurance
	}
}

function Ef(x, y, type, value, colortype) {
	this.x = x
	this.y = y
	this.type = type
	this.value = value
	this.colortype = colortype
	this.size = 1
	this.index = 0
	this.stop = false
	this.canDelete = 0
	this.alp = 100
	this.w = 0
	this.h = 0
	this.length = 0
	if (this.type == 1) {
		this.size = 0
		this.wmax = 50
		this.alp = 50
		this.duration = 50
		this.rrr = this.colortype[0]
		this.ggg = this.colortype[1]
		this.bbb = this.colortype[2]
		this.rr = 255
		this.gg = 255
		this.bb = 255
		this.rv = (this.rr - this.rrr) / this.duration
		this.gv = (this.gg - this.ggg) / this.duration
		this.bv = (this.bb - this.bbb) / this.duration
	}
	this.paint = function(ctx) {
		ctx.globalAlpha = this.alp / 100
		if (this.type == 1) {
			this.paintNum(this.value, this.colortype, this.x - xPass, this.y - yPass, this.size * this.wmax)
		}
		ctx.globalAlpha = 1
	}
	this.paintNum = function(v, type, x, y, size) {
		var ll = v.toString().length
		ctx.font = size + "px Comic Sans MS"
		ctx.fillStyle = "rgb(" + this.rr + "," + this.gg + "," + this.bb + ")"
		ctx.fillText(v, x - ll * size / 2 + size, y - size / 2)
		ctx.strokeStyle = "rgb(0,0,0)"
		ctx.lineWidth = size / 100
		ctx.strokeText(v, x - ll * size / 2 + size, y - size / 2)
	}
	this.move = function() {
		if (this.type == 1) {
			if (!this.stop) {
				this.index++
				var ii = this.index * (Math.PI / this.duration) / 8
				if (this.alp < 100) {
					this.alp += 200 / this.duration
				}
				if (this.index <= this.duration) {
					this.rr -= this.rv
					this.gg -= this.gv
					this.bb -= this.bv
				}
				if (this.size < 1) {
					this.size += 2 / this.duration
				}
				this.y -= Math.cos(ii)
				if (Math.cos(ii) <= 0) {
					this.stop = true
				}
			} else {
				if (this.alp <= 4) {
					this.canDelete = 1
				} else {
					this.alp -= 4
				}
			}
		}
	}
}

function Bg(x, y, type, other, w, h, moveDis, speed) {//other:触发事件
	this.x = x//中心点
	this.y = y
	this.type = type
	this.other = other
	this.speed = speed
	this.w = w
	this.h = h
	this.moveDis = moveDis
	this.canstop = false
	this.iftouched = false//检测是否角色站于其上
	this.alp = 100//透明
	if (this.speed == undefined) {
		this.speed = 0
	}
	if (this.type == 1) {
		//该处若speed==1则为一触即消失,2为一触即落下
		this.state = speed
		//静止平台
		this.canstop = 1
		if (this.w == undefined) {
			this.w = 300
			this.h = 100
		}
	}
	if (this.type == 2) {
		//上下移动平台
		this.canstop = 1
		if (this.speed == undefined) {
			this.speed = 2
		}
		if (this.w == undefined) {
			this.w = 300
			this.h = 100
		}
		if (this.moveDis == undefined) {
			this.moveDis = 200
		}
		this.ymax = this.y + this.moveDis / 2
		this.ymin = this.y - this.moveDis / 2

	}
	if (this.type == 3) {
		//左右移动平台
		this.canstop = 1
		if (this.speed == undefined) {
			this.speed = 2
		}
		if (this.w == undefined) {
			this.w = 300
			this.h = 100
		}
		if (this.moveDis == undefined) {
			this.moveDis = 200
		}
		this.xmax = this.x + this.moveDis / 2
		this.xmin = this.x - this.moveDis / 2

	}
	if (this.type == 4) {
		this.t = other//1为向右,-1向左
		this.canstop = 2
		//三角
		if (this.w == undefined) {
			this.w = 300
			this.h = 300
		}
		this.d = Math.atan(this.h / this.w)//倾角
	}
	this.paint = function(ctx) {
		ctx.globalAlpha = this.alp / 100
		if (this.type == 1 || this.type == 2 || this.type == 3) {
			ctx.fillStyle = "lime"
			ctx.fillRect(this.x - this.w / 2 - xPass + shakex, this.y - this.h / 2 - yPass + shakey, this.w, this.h)
			if (this.state == 1) {
				ctx.fillStyle = "grey"
			} else {
				ctx.fillStyle = "#87531f"
			}
			ctx.fillRect(this.x - this.w / 2 - xPass + shakex, this.y - this.h / 2 + 10 - yPass + shakey, this.w, this.h - 10)
		}
		if (this.type == 4) {
			ctx.translate(-xPass + shakex, -yPass + shakey)
			ctx.fillStyle = "#87531f"
			ctx.beginPath();
			ctx.moveTo(this.x - this.w / 2 * this.t, this.y - this.h / 2)
			ctx.lineTo(this.x + this.w / 2 * this.t, this.y + this.h / 2)
			ctx.lineTo(this.x - this.w / 2 * this.t, this.y + this.h / 2)
			ctx.lineTo(this.x - this.w / 2 * this.t, this.y - this.h / 2)
			ctx.closePath();
			ctx.fill();
			ctx.strokeStyle = "lime"
			ctx.lineWidth = 10
			ctx.beginPath();
			ctx.moveTo(this.x - this.w / 2 * this.t, this.y - this.h / 2)
			ctx.lineTo(this.x + this.w / 2 * this.t, this.y + this.h / 2)
			ctx.closePath();
			ctx.stroke();
			ctx.setTransform(1, 0, 0, 1, 0, 0)
		}
		ctx.globalAlpha = 1
	}
	this.move = function() {
		if (this.type == 1) {
			if (this.state == 1) {
				if (this.iftouched) {
					this.alp -= 4
					if (this.alp <= 4) {
						this.alp = 0
						this.canDelete = 1
					}
				}
			}
		}
		if (this.type == 2) {
			this.y += this.speed
			if (this.y >= this.ymax || this.y <= this.ymin) {
				this.speed = -this.speed
			}
		}
		if (this.type == 3) {
			this.x += this.speed
			if (this.x >= this.xmax || this.x <= this.xmin) {
				this.speed = -this.speed
			}
		}
	}
}

//全屏
function launchFullscreen(element) {
	if (element.requestFullscreen) {
		element.requestFullscreen();
	} else if (element.mozRequestFullScreen) {
		element.mozRequestFullScreen();
	} else if (element.webkitRequestFullscreen) {
		element.webkitRequestFullscreen();
	} else if (element.msRequestFullscreen) {
		element.msRequestFullscreen();
	}
}

// 判断浏览器种类
function exitFullscreen() {
	if (document.exitFullscreen) {
		document.exitFullscreen();
	} else if (document.mozCancelFullScreen) {
		document.mozCancelFullScreen();
	} else if (document.webkitExitFullscreen) {
		document.webkitExitFullscreen();
	}
}

function BriefPaint() {//头像，血量，魔法值,经验值
	//头像
	ctx.drawImage(sign[-1], 0, 0, 120, 120)
	ctx.drawImage(sign[heroType], 10, 10, 100, 100)
	ctx.drawImage(sign[-1], 0, 0, 50, 50)
	ctx.font = "45px 幼圆"
	ctx.fillStyle = "rgba(255,255,255,1)"
	if (level <= 9) {
		ctx.fillText(level, 15, 40)
	} else {
		if (level <= 99) {
			ctx.fillText(level, 4, 40)
		}
	}
}

function Allpaint() {
	for (var i = 0; i < bgs.length; i++) {
		if (bgs[i].x + bgs[i].w / 2 >= xPass && bgs[i].x - bgs[i].w / 2 <= 1500 + xPass && bgs[i].y + bgs[i].h / 2 >= yPass && bgs[i].y - bgs[i].h / 2 <= 1500 + yPass) {
			bgs[i].paint(ctx)
		}
	}
	for (var i = 0; i < hs.length; i++) {
		//if (hs[i].x + hs[i].w / 2 >= xPass && hs[i].x - hs[i].w / 2 <= 1500 + xPass && hs[i].y + hs[i].h / 2 >= yPass && hs[i].y - hs[i].h / 2 <= 1500 + yPass) {
		hs[i].paint(ctx)
		//}
	}
	for (var i = 0; i < bullets.length; i++) {
		bullets[i].paint(ctx)
	}
	for (var i = 0; i < efs.length; i++) {
		efs[i].paint(ctx)
	}
	BriefPaint()
}

//背景绘画
function BgPaint() {
	//第一关
	if (game == 1) {
		for (var i = 0; i < Max(worldWidth[game] / 3000); i++) {
			ctx.translate(1500 - xPass * 0.6 + i * 3000 + shakex, 750 - yPass * 0.6 + shakey)
			var st = 1
			if (i % 2 == 1) {
				st = -1
			}
			ctx.scale(st, 1)
			ctx.drawImage(bg[0], -1500, -750, 3000, 1500)
			ctx.setTransform(1, 0, 0, 1, 0, 0)
		}
	}
	//间隔
	if (ifThroughLocked) {
		ctx.fillStyle = "rgba(50,100,180,0.3)"
		for (var i = 0; i <= dividedWorld; i++) {
			ctx.fillRect(worldDividedXHome[game-1][i][0] - 50 - xPass, worldDividedYHome[game-1][i][0] - yPass, 100, Math.abs(worldDividedYHome[game-1][i][0] - worldDividedYHome[game-1][i][1]))
			ctx.fillRect(worldDividedXHome[game-1][i][1] - 50 - xPass, worldDividedYHome[game-1][i][0] - yPass, 100, Math.abs(worldDividedYHome[game-1][i][0] - worldDividedYHome[game-1][i][1]))
		}
	}
}

function Allmove() {
	for (var i = 0; i < hs.length; i++) {
		hs[i].move()
	}
	for (var i = 0; i < bgs.length; i++) {
		bgs[i].move()
	}
	for (var i = 0; i < efs.length; i++) {
		efs[i].move()
	}
	for (var i = 0; i < bullets.length; i++) {
		bullets[i].move()
	}
	//摇晃检查
	if (ifshake) {
		shakin--
		//shakex=Math.random()*shakeA-2*shakeA
		shakey = Math.random() * shakeA - 2 * shakeA
		if (shakin <= 0) {
			shakin = 0
			ifshake = false
		}
	} else {
		shakex = 0
		shakey = 0
	}
}

function Allcheck() {
	for (var i = 0; i < hs.length; i++) {
		if (hs[i].canDelete == 1) {
			hs.splice(i, 1)
		}
	}
	for (var i = 0; i < bgs.length; i++) {
		if (bgs[i].canDelete == 1) {
			bgs.splice(i, 1)
		}
	}
	for (var i = 0; i < efs.length; i++) {
		if (efs[i].canDelete == 1) {
			efs.splice(i, 1)
		}
	}
}

//按键设置
//奔跑
var xmove = document.addEventListener("keydown", function(e) {
	var m = e.keyCode
	if (hs[0] != undefined && hs[0].state != 3 && !hs[0].NoMove) {
		if (m == 65) {
			if (hs[0] != undefined) {
				if (hs[0].t == 1) {
					//hs[0].v = 0
				}
				hs[0].xmove = true
				hs[0].t = -1//向左
			}
		}
		if (m == 68) {
			if (hs[0] != undefined) {
				if (hs[0].t == -1) {
					//hs[0].v = 0
				}
				hs[0].xmove = true
				hs[0].t = 1//向右
			}
		}
	}
});
//跳跃
var jumpdown = document.addEventListener("keydown", function(e) {
	var m = e.keyCode
	if (m == 75) {
		if (hs[0] != undefined && !hs[0].NoJump && hs[0].state != 3) {
			if (hs[0].jtime < hs[0].availableJumpTime) {//可跳跃次数
				hs[0].ifjump = true
				hs[0].vy = -12
				hs[0].bodyUpD = 0
				hs[0].rfinished = false
				hs[0].jtime++
			}
		}
	}
});
//攻击
var attack = document.addEventListener("keydown", function(e) {
	if (hs[0] != undefined && hs[0].state != 3) {
		var m = e.keyCode
		if (hs[0] != undefined && hs[0].state != 3) {
			if (m == 74) {
				if (hs[0] != undefined && !hs[0].NoAttack && hs[0].actfinished) {
					if (!hs[0].ifActKeyDown) {
						hs[0].ifActKeyDown = true
						hs[0].state = 2
						hs[0].actstate = 0
						hs[0].actindex = 0
						//空中只能1普攻
						if (!hs[0].ystop && hs[0].actstate == 0 && hs[0].actn != 4) {
							hs[0].actn = 1
						}
						if (hs[0].actfinished) {
							hs[0].actfinished = false
						}
					}
				}
			}
			//U
			if (m == 85) {
				if (hs[0] != undefined && !hs[0].NoSkill && hs[0].actfinished) {
					if (!hs[0].ifActKeyDown && hs[0].magic >= hs[0].skillCostMagic[0]) {
						hs[0].ifActKeyDown = true
						hs[0].state = 2
						hs[0].actstate = 1
						hs[0].magic -= hs[0].skillCostMagic[0]
						hs[0].actindex = 0
						if (hs[0].actfinished) {
							hs[0].actfinished = false
						}
					}
				}
			}
			//I
			if (m == 73) {
				if (hs[0] != undefined && !hs[0].NoSkill && hs[0].actfinished) {
					if (!hs[0].ifActKeyDown && hs[0].magic >= hs[0].skillCostMagic[1]) {
						hs[0].ifActKeyDown = true
						hs[0].state = 2
						hs[0].actstate = 2
						hs[0].magic -= hs[0].skillCostMagic[1]
						hs[0].actindex = 0
						if (hs[0].actfinished) {
							hs[0].actfinished = false
						}
					}
				}
			}
			//O
			if (m == 79) {
				if (hs[0] != undefined && !hs[0].NoSkill && hs[0].actfinished) {
					if (!hs[0].ifActKeyDown && hs[0].magic >= hs[0].skillCostMagic[2]) {
						hs[0].ifActKeyDown = true
						hs[0].state = 2
						hs[0].actstate = 3
						hs[0].magic -= hs[0].skillCostMagic[2]
						hs[0].actindex = 0
						if (hs[0].actfinished) {
							hs[0].actfinished = false
						}
					}
				}
			}
			//L
			if (m == 76) {
				if (hs[0] != undefined && !hs[0].NoSkill && hs[0].actfinished) {
					if (!hs[0].ifActKeyDown && hs[0].magic >= hs[0].skillCostMagic[3]) {
						hs[0].ifActKeyDown = true
						hs[0].state = 2
						hs[0].actstate = 4
						hs[0].magic -= hs[0].skillCostMagic[3]
						hs[0].actindex = 0
						if (hs[0].actfinished) {
							hs[0].actfinished = false
						}
					}
				}
			}
			//测试
			/*if (m == 76) {
			 if (hs[0] != undefined) {
			 hs[0].life += 10
			 //hs[0].size += 0.05
			 exp += Math.round(expmax / 10)
			 return
			 }
			 }*/
		}
	}
});
//传送
var expressing = document.addEventListener("keydown", function(e) {
	var m = e.keyCode
	if (m == 70) {
		if (hs[0] != undefined) {
			hs[0].express = true
			hs[0].expressin = 0
		}
	}
});

//按键回弹
var keyback = document.addEventListener("keyup", function(e) {
	var m = e.keyCode
	if (m == 65 || m == 68) {
		if (hs[0] != undefined) {
			hs[0].xmove = false
		}
	}
	if (m == 74 || m == 85 || m == 73 || m == 79 || m == 76) {
		if (hs[0] != undefined) {
			if (hs[0].state != 3 && hs[0].actfinished) {
				hs[0].state = 1
			}
			hs[0].actin = 0
			hs[0].ifActKeyDown = false
		}
	}
});
//人物
canvas.onclick = function() {
	if (hs.length == 0) {
		Initializing(game)
		if (heroType == 0) {
			var c = new H(1, heroxy[level-1][0], heroxy[level-1][1], level, Life, Magic, Lifeback, Magicback, Dmg, Escape, Defense, Kill, [], 1, Accurance, Toughness)
			hs.splice(0, 0, c)
			hs[hs.length] = new H(-0.3, 500, 100, 1)
		}
	}
	//hs[hs.length] = new H(2, Hx, Hy - 300, 1, Life * 2, Magic, Lifeback, Magicback, Dmg, 0, 0, Kill, [], 2, Accurance, 5, true, 10)
	hs[hs.length] = new H(3, Hx, Hy - 300, 1, Life * 5, Magic, Lifeback, Magicback, Dmg / 5, 0, 0, Kill, [], 2, 1e5, 5e5, true, 100)
}
//子弹
function Bullet(x, y, type, dmg, kill, accurance, size) {
	this.x = x
	this.y = y
	this.type = type
	this.dmg = dmg
	this.kill = kill
	this.accurance = accurance
	this.size = size
	this.canDelete = 0
	this.throughArr = [];
	//贯穿
	this.paint = function(ctx) {

	}
	this.move = function() {

	}
}

function Hlocated() {
	//寻常定位
	if (!ifThroughLocked) {
		if (hs.length > 0) {
			Hx = hs[0].x
			Hy = hs[0].y
		}
		if (Hx <= 750) {
			xPass = 0
		}
		if (Hx > 750 && Hx < worldWidth[game - 1] - 750) {
			xPass = Hx - 750
		}
		if (Hy <= 375) {
			yPass = 0
		}
		if (Hy > 375 && Hy < worldHeight[game - 1] - 375) {
			yPass = Hy - 375
		}
	} else {
		//分割世界定位
		if (hs.length > 0) {
			Hx = hs[0].x
			Hy = hs[0].y
		}
		if (Hx <= 750 + worldDividedXHome[game - 1][dividedWorld][0]) {
			xPass = worldDividedXHome[game - 1][dividedWorld][0]
		}
		if (Hx > 750 + worldDividedXHome[game - 1][dividedWorld][0] && Hx < worldDividedXHome[game - 1][dividedWorld][1] - 750) {
			xPass = Hx - 750
		}
		if (Hy <= 375 + worldDividedYHome[game - 1][dividedWorld][0]) {
			yPass = worldDividedYHome[game - 1][dividedWorld][0]
		}
		if (Hy > 375 && Hy < worldDividedYHome[game - 1][dividedWorld][1] - 375) {
			yPass = Hy - 375
		}
	}
	//掉下悬崖
	for (var i = 0; i < hs.length; i++) {
		if (hs[i].team == 1) {
			if (hs[i].y - hs[i].h / 2 >= worldHeight[game - 1]) {
				if (i == 0) {
					hs[0].life -= Math.round(hs[0].blife / 4)
					hs[0].x = heroxy[game-1][0] + worldDividedXHome[game-1][dividedWorld][0]
					hs[0].y = heroxy[game-1][1] + worldDividedYHome[game-1][dividedWorld][0]
					hs[0].vy = 0
				} else {
					hs[i].x = hs[0].x
					hs[i].y = hs[0].y
				}
			}
		} else {
			if (hs[i].y - hs[i].h / 2 >= worldHeight[game - 1]) {
				hs[i].life = 0
			}
		}
	}
	//分割世界定位
	for (var i = 0; i < worldDividedXHome[game - 1].length; i++) {
		if (hs[0].x >= worldDividedXHome[game-1][i][0] && hs[0].x < worldDividedXHome[game-1][i][1] && hs[0].y >= worldDividedYHome[game-1][i][0] && hs[0].y < worldDividedYHome[game-1][i][1]) {
			dividedWorld = i
		}
	}
	//到新分割世界自动锁定
	if (dividedWorld > throughdividedWorld) {
		ifThroughLocked = true
		throughdividedWorld = dividedWorld
	}
}

function Max(v) {
	var s = parseInt(v)
	if (s < v) {
		s += 1
	}
	return s
}

function DChange(d) {//将所有角度转换成-180~180°
	var c = d
	while (true) {
		if (d >= Math.PI * 2) {
			d -= Math.PI * 2
		} else {
			if (d <= -Math.PI * 2) {
				d += Math.PI * 2
			} else {
				if (d >= -Math.PI && d <= Math.PI) {
					c = d
					return c
				} else {
					if (d > Math.PI) {
						d = d - Math.PI * 2
					}
					if (d < -Math.PI) {
						d = d + Math.PI * 2
					}
				}
			}
		}
	}
}

function Update() {//检查角色升级，配备角色数据
	//升级
	if (exp >= expmax) {
		if (level + 1 < blank[heroType].length) {
			exp -= expmax
			level++
			//alert("恭喜你，升级啦！")
		}
	}
	expmax = blank[heroType][level][1]
	//配备数据
	Dmg = blank[heroType][level][2]
	Life = blank[heroType][level][3]
	Magic = blank[heroType][level][4]
	Lifeback = blank[heroType][level][5]
	Magicback = blank[heroType][level][6]
	Escape = blank[heroType][level][7]
	Kill = blank[heroType][level][8]
	Defense = blank[heroType][level][9]
	Accurance = blank[heroType][level][10]
	Toughness = blank[heroType][level][11]
}

function Initializing(l) {//初始化
	Update();
	hs = []
	ifERelease = false//怪物是否释放
	efs = []
	bgs = []
	bullets = []
	beatedENum = 0//击败怪物数量
	throughdividedWorld = 0
	ifGameFinished = false//该关卡是否完成
	wave = 0;
	creatEnemyIndex = 0//造怪index
	haveCreatedENum = 0//已经造怪数
	//波数
	dividedWorld = 0
	ifThroughLocked = true
	ifshake = false, shakin = 0
	shakx = 0
	shaky = 0, shakeA = 0
	wave = 0
	CreatBg(l)
}

function CheckWorldThrough() {
	if (beatedENum >= worldThroughHome[game-1][dividedWorld][wave]) {
		wave++
		beatedENum = 0
		if (ifThroughLocked) {
			ifERelease = false
		}
	}
	if (wave >= worldThroughHome[game-1][dividedWorld].length) {
		if (dividedWorld >= worldThroughHome[game - 1].length - 1 && wave >= worldThroughHome[game-1][dividedWorld].length && !ifGameFinished) {
			ifGameFinished = true
			hs[hs.length] = new H(-0.3, worldDividedXHome[game-1][dividedWorld][0] + (worldDividedXHome[game-1][dividedWorld][1] - worldDividedXHome[game-1][dividedWorld][0]) / 2, 0, 1)
		}
		wave = 0
		ifThroughLocked = false
	}
	if (dividedWorld < throughdividedWorld) {
		beatedENum = 0
	}
}

function probability(a) {
	var t = false
	if (Math.random() <= a) {
		t = true
	}
	return t
}

function Not0(value) {
	if (value < 0) {
		value = 0
	}
	return value
}

function AutoCreatEnemy(l) {
	//自动生成敌人
	if (hs[0] != undefined) {
		if (wave < worldThroughHome[game - 1][dividedWorld].length && !ifERelease && dividedWorld >= throughdividedWorld && ifThroughLocked) {
			if (hs[0].x + hs[0].w / 2 >= worldGameXHome[game - 1][dividedWorld][0] && hs[0].x - hs[0].w / 2 <= worldGameXHome[game - 1][dividedWorld][1] && hs[0].y + hs[0].h / 2 >= worldGameYHome[game - 1][dividedWorld][0] && hs[0].y - hs[0].h / 2 <= worldGameYHome[game - 1][dividedWorld][1]) {
				//在范围内
				if (haveCreatedENum < worldThroughHome[game-1][dividedWorld][wave]) {
					creatEnemyIndex++
					if (creatEnemyIndex >= worldEDuration[game-1][dividedWorld][wave]) {
						creatEnemyIndex = 0
						var detail = worldEHome[game-1][dividedWorld][wave][haveCreatedENum]
						hs[hs.length] = new H(detail[2], detail[0], detail[1], 1, detail[3], 0, detail[4], 0, detail[5], detail[6], detail[7], detail[8], [], detail[9], detail[10], detail[11], true, detail[12])
						haveCreatedENum++
					}
				} else {
					haveCreatedENum = 0
					creatEnemyIndex = 0
					ifERelease = true
				}
			}
		}
	}
}

function CreatBg(l) {
	//创造背景
	if (l == 1) {
		bgs[bgs.length] = new Bg(500, 800, 1, 0, 1000, 800)
		bgs[bgs.length] = new Bg(1350, 1055, 1, 0, 700, 310)
		bgs[bgs.length] = new Bg(1350, 650, 4, 1, 700, 500)
		bgs[bgs.length] = new Bg(2200, 1050, 1, 0, 1000, 300)
		bgs[bgs.length] = new Bg(2950, 750, 1, 0, 300, 50)
		bgs[bgs.length] = new Bg(3350, 450, 1, 0, 300, 50)
		bgs[bgs.length] = new Bg(3750, 750, 1, 0, 300, 50)
		bgs[bgs.length] = new Bg(4500, 1050, 1, 0, 1000, 300)
		bgs[bgs.length] = new Bg(5500, 1050, 1, 0, 1000, 300)
		bgs[bgs.length] = new Bg(4950, 750, 1, 0, 100, 300)
		bgs[bgs.length] = new Bg(5950, 750, 1, 0, 100, 300)
		bgs[bgs.length] = new Bg(5100, 575, 1, 0, 400, 50)
		bgs[bgs.length] = new Bg(5800, 575, 1, 0, 400, 50)
		bgs[bgs.length] = new Bg(6250, 700, 2, 0, 300, 50, 300, 2)
		bgs[bgs.length] = new Bg(7350, 1050, 1, 0, 1700, 300)
		//bgs[bgs.length] = new Bg(1350, 650, 4, 1,700,500)
	}
	if (l == 2) {
		bgs[bgs.length] = new Bg(500, 800, 1, 0, 1000, 800)
		bgs[bgs.length] = new Bg(1350, 1055, 1, 0, 700, 310)
		bgs[bgs.length] = new Bg(1350, 650, 4, 1, 700, 500)
		bgs[bgs.length] = new Bg(2200, 1050, 1, 0, 1000, 300)
		bgs[bgs.length] = new Bg(2950, 750, 1, 0, 300, 50)
		bgs[bgs.length] = new Bg(3350, 450, 1, 0, 300, 50)
		bgs[bgs.length] = new Bg(3750, 750, 1, 0, 300, 50)
		bgs[bgs.length] = new Bg(4500, 1050, 1, 0, 1000, 300)
		bgs[bgs.length] = new Bg(5500, 1050, 1, 0, 1000, 300)
		bgs[bgs.length] = new Bg(4950, 750, 1, 0, 100, 300)
		bgs[bgs.length] = new Bg(5950, 750, 1, 0, 100, 300)
		bgs[bgs.length] = new Bg(5100, 575, 1, 0, 400, 50)
		bgs[bgs.length] = new Bg(5800, 575, 1, 0, 400, 50)
		bgs[bgs.length] = new Bg(6250, 700, 2, 0, 300, 50, 300, 2)
		bgs[bgs.length] = new Bg(7350, 1050, 1, 0, 1700, 300)
		//bgs[bgs.length] = new Bg(1350, 650, 4, 1,700,500)
	}
	/*
	 if (l == 2) {
	 //大板块
	 bgs[bgs.length] = new Bg(2250, 800, 1, 0, 4500, 100)
	 //小板块
	 bgs[bgs.length] = new Bg(150, 600, 1, 0, 300, 300)
	 bgs[bgs.length] = new Bg(1200, 600, 1, 0, 300, 300)
	 bgs[bgs.length] = new Bg(1600, 600, 4, 1, 500, 300)
	 bgs[bgs.length] = new Bg(2500, 600, 4, -1, 500, 300)
	 bgs[bgs.length] = new Bg(2900, 600, 1, 0, 300, 300)
	 bgs[bgs.length] = new Bg(3250, 600, 4, 1, 400, 300)
	 bgs[bgs.length] = new Bg(4650, 400, 2, 0, 100, 50, 300, 2)
	 bgs[bgs.length] = new Bg(4850, 200, 1, 0, 300, 100)
	 bgs[bgs.length] = new Bg(4650, 900, 4, 1, 300, 300)
	 bgs[bgs.length] = new Bg(4850, 1300, 4, -1, 300, 300)
	 //下
	 bgs[bgs.length] = new Bg(250, 1750, 2, 0, 500, 100, 500, 2)
	 bgs[bgs.length] = new Bg(700, 1300, 1, 0, 200, 50)
	 bgs[bgs.length] = new Bg(1000, 1100, 1, 0, 200, 50)
	 bgs[bgs.length] = new Bg(1300, 1300, 1, 0, 200, 50)
	 bgs[bgs.length] = new Bg(2100, 1400, 1, 0, 1000, 100)
	 bgs[bgs.length] = new Bg(2100, 1200, 3, 0, 100, 300, 1000, 3)
	 bgs[bgs.length] = new Bg(2800, 1100, 1, 0, 200, 50)
	 bgs[bgs.length] = new Bg(2950, 975, 1, 0, 100, 250)
	 bgs[bgs.length] = new Bg(2700, 1500, 1, 0, 100, 50, 0, 1)
	 bgs[bgs.length] = new Bg(2800, 1500, 1, 0, 100, 50, 0, 1)
	 bgs[bgs.length] = new Bg(2900, 1500, 1, 0, 100, 50, 0, 1)
	 bgs[bgs.length] = new Bg(3000, 1500, 1, 0, 100, 50, 0, 1)
	 bgs[bgs.length] = new Bg(3000, 1750, 4, -1, 500, 500)
	 bgs[bgs.length] = new Bg(3500, 1750, 1, 0, 500, 500)
	 bgs[bgs.length] = new Bg(4050, 1750, 4, 1, 600, 500)
	 //boss所在地
	 bgs[bgs.length] = new Bg(2000, 1950, 1, 0, 2000, 100)
	 //测试
	 }*/
	if (l == 3) {
		//大板块
		bgs[bgs.length] = new Bg(500, 800, 1, 0, 1000, 800)
	}
	//创建人物
	var c = new H(1, heroxy[game-1][0], heroxy[game-1][1], level, Life, Magic, Lifeback, Magicback, Dmg, Escape, Defense, Kill, [], 1, Accurance, Toughness, false, 0, [true, 0, 0])
	hs.splice(0, 0, c)
	//hs[hs.length] = new H(-0.3, 500, 100, 1)
}
